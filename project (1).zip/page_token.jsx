/* Digital Token Pass — Boarding-pass aesthetic */

function getToken() {
  try {
    const raw = localStorage.getItem('ks_token');
    if (raw) return JSON.parse(raw);
  } catch {}
  // Fallback demo token
  return {
    id:'KS-A9F2K3', tokenNo:'A-247',
    farmer:'Ramesh Kumar', farmerHi:'रमेश कुमार',
    aadhaar:'XXXX-XXXX-4782', village:'Rauni, Ludhiana',
    crop:'wheat', weight:'25', date:'tomorrow', time:'10:00 AM',
    vehicle:'tractor', vehicleNo:'PB-10-AB-4567', mandi:'Khanna Mandi, Ludhiana',
    cropObj: { icon:'🌾', name:'Wheat', hi:'गेहूं', msp:'₹2,425/qtl' },
    vehicleObj:{ icon:'🚜', name:'Tractor + Trolley', hi:'ट्रैक्टर-ट्रॉली' },
    queuePosition:7, etaMin:42, issuedAt:new Date().toISOString(),
  };
}

// Fake but visually-convincing QR (deterministic grid)
function FakeQR({ text = 'KS-A9F2K3', size = 140 }) {
  const grid = 25;
  const cells = useMemo(() => {
    let seed = 0;
    for (let i = 0; i < text.length; i++) seed = (seed * 31 + text.charCodeAt(i)) | 0;
    const rand = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
    const arr = [];
    for (let y = 0; y < grid; y++) for (let x = 0; x < grid; x++) arr.push(rand() > 0.5);
    return arr;
  }, [text]);
  const cell = size / grid;
  const isFinder = (x,y) => (
    (x<7 && y<7) || (x>=grid-7 && y<7) || (x<7 && y>=grid-7)
  );
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{background:'#fff', display:'block'}}>
      {cells.map((on, i) => {
        const x = i % grid, y = Math.floor(i / grid);
        if (isFinder(x,y)) return null;
        return on ? <rect key={i} x={x*cell} y={y*cell} width={cell} height={cell} fill="#0f172a" /> : null;
      })}
      {/* Finder squares */}
      {[[0,0],[grid-7,0],[0,grid-7]].map(([fx,fy],i)=>(
        <g key={i}>
          <rect x={fx*cell} y={fy*cell} width={cell*7} height={cell*7} fill="#0f172a"/>
          <rect x={(fx+1)*cell} y={(fy+1)*cell} width={cell*5} height={cell*5} fill="#fff"/>
          <rect x={(fx+2)*cell} y={(fy+2)*cell} width={cell*3} height={cell*3} fill="#0f172a"/>
        </g>
      ))}
    </svg>
  );
}

function CountdownETA({ minutes }) {
  const [remaining, setRemaining] = useState(minutes * 60);
  useEffect(() => {
    const iv = setInterval(() => setRemaining(r => Math.max(0, r - 1)), 1000);
    return () => clearInterval(iv);
  }, []);
  const m = Math.floor(remaining / 60);
  const s = remaining % 60;
  return <span className="tabular">{m}m {String(s).padStart(2,'0')}s</span>;
}

function TokenPage({ navigate }) {
  const t = getToken();
  const [queuePos, setQueuePos] = useState(t.queuePosition);
  useEffect(() => {
    // Simulate queue advancement
    const iv = setInterval(() => setQueuePos(p => Math.max(1, p - 1)), 12000);
    return () => clearInterval(iv);
  }, []);

  return (
    <div className="page">
      <div className="page-title">
        <div>
          <h2>Your Mandi Token · आपका मंडी टोकन</h2>
          <div className="hindi">यह पर्ची गेट पर दिखाइए</div>
          <div className="sub">Show this pass at the mandi gate. Also sent via SMS to your registered number.</div>
        </div>
        <div className="hstack" style={{gap:10}}>
          <button className="btn btn-outline" onClick={()=>window.print()}>🖨️ Print</button>
          <button className="btn btn-outline">📱 Send SMS</button>
          <button className="btn btn-saffron" onClick={()=>navigate('/track')}>📍 Track Live →</button>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:'1.35fr 1fr', gap:24}}>

        {/* Boarding pass */}
        <div style={{position:'relative'}}>
          <div style={{
            background:'#fff',
            borderRadius:12, overflow:'hidden',
            boxShadow:'0 20px 50px rgba(15,23,42,.15), 0 4px 10px rgba(15,23,42,.08)',
            display:'grid', gridTemplateColumns:'1fr 220px',
            minHeight:340, position:'relative',
          }}>
            {/* Header stripe */}
            <div style={{gridColumn:'1 / -1', background:'var(--navy)', color:'#fff', padding:'10px 20px', display:'flex', justifyContent:'space-between', alignItems:'center', fontSize:12, fontFamily:'var(--mono)'}}>
              <div className="hstack" style={{gap:10}}>
                <span style={{fontSize:16}}>🌾</span>
                <span style={{letterSpacing:1.5, fontWeight:700}}>KRISHISETU · MANDI ENTRY PASS</span>
              </div>
              <div style={{opacity:.8}}>ID: {t.id}</div>
            </div>

            {/* LEFT · trip info */}
            <div style={{padding:'24px 24px 20px', fontFamily:'var(--mono)'}}>
              <div style={{display:'grid', gridTemplateColumns:'1fr auto 1fr', alignItems:'center', gap:20, marginBottom:24}}>
                <div>
                  <div style={{fontSize:10, color:'var(--ink-3)', letterSpacing:1}}>FARMER / किसान</div>
                  <div style={{fontSize:22, fontWeight:700, color:'var(--navy)', marginTop:4, fontFamily:'system-ui'}}>{t.farmer}</div>
                  <div style={{fontSize:14, color:'var(--ink-2)', fontFamily:'system-ui'}}>{t.farmerHi}</div>
                  <div style={{fontSize:11, color:'var(--ink-3)', marginTop:4}}>Aadhaar {t.aadhaar}</div>
                </div>
                <div style={{fontSize:24, color:'var(--saffron)'}}>➜</div>
                <div>
                  <div style={{fontSize:10, color:'var(--ink-3)', letterSpacing:1}}>MANDI / मंडी</div>
                  <div style={{fontSize:18, fontWeight:700, color:'var(--navy)', marginTop:4, fontFamily:'system-ui'}}>{t.mandi.split(',')[0]}</div>
                  <div style={{fontSize:14, color:'var(--ink-2)', fontFamily:'system-ui'}}>{t.mandi.split(',')[1] || ''}</div>
                  <div style={{fontSize:11, color:'var(--ink-3)', marginTop:4}}>Gate 2 · Block C</div>
                </div>
              </div>

              <div style={{display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14, borderTop:'2px dashed var(--line)', paddingTop:16}}>
                <div>
                  <div style={{fontSize:10, color:'var(--ink-3)', letterSpacing:1}}>CROP</div>
                  <div style={{fontSize:18, fontWeight:700, marginTop:2, fontFamily:'system-ui'}}>{t.cropObj?.icon} {t.cropObj?.name}</div>
                  <div style={{fontSize:11, color:'var(--ink-3)', fontFamily:'system-ui'}}>{t.cropObj?.hi}</div>
                </div>
                <div>
                  <div style={{fontSize:10, color:'var(--ink-3)', letterSpacing:1}}>WEIGHT</div>
                  <div style={{fontSize:18, fontWeight:700, marginTop:2}}>{t.weight} qtl</div>
                  <div style={{fontSize:11, color:'var(--ink-3)', fontFamily:'system-ui'}}>क्विंटल</div>
                </div>
                <div>
                  <div style={{fontSize:10, color:'var(--ink-3)', letterSpacing:1}}>DATE</div>
                  <div style={{fontSize:18, fontWeight:700, marginTop:2, fontFamily:'system-ui', textTransform:'capitalize'}}>{t.date}</div>
                  <div style={{fontSize:11, color:'var(--ink-3)'}}>{t.time}</div>
                </div>
                <div>
                  <div style={{fontSize:10, color:'var(--ink-3)', letterSpacing:1}}>VEHICLE</div>
                  <div style={{fontSize:14, fontWeight:700, marginTop:2}}>{t.vehicleNo}</div>
                  <div style={{fontSize:11, color:'var(--ink-3)', fontFamily:'system-ui'}}>{t.vehicleObj?.icon} {t.vehicleObj?.hi}</div>
                </div>
              </div>

              <div style={{marginTop:16, padding:'10px 12px', background:'var(--green-3)', border:'1px solid #b8dbb2', borderRadius:6, fontSize:12, color:'var(--ink-2)', fontFamily:'system-ui'}}>
                <b style={{color:'var(--green)'}}>✓ MSP guaranteed:</b> {t.cropObj?.msp} · Payment via PFMS DBT within 72 hours of acceptance
              </div>
            </div>

            {/* Perforated divider */}
            <div style={{
              position:'absolute', left: 'calc(100% - 220px)', top: 40, bottom: 0, width: 1,
              background:'repeating-linear-gradient(to bottom, #cbd5e1 0, #cbd5e1 4px, transparent 4px, transparent 8px)'
            }}/>
            {/* Punch holes */}
            <div style={{position:'absolute', left:'calc(100% - 230px)', top: 34, width:20, height:20, background:'var(--bg)', borderRadius:'50%'}}/>
            <div style={{position:'absolute', left:'calc(100% - 230px)', bottom:-10, width:20, height:20, background:'var(--bg)', borderRadius:'50%'}}/>

            {/* RIGHT · Token + QR */}
            <div style={{padding:'24px 20px 20px', background:'#fafbfd', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'space-between'}}>
              <div style={{textAlign:'center'}}>
                <div style={{fontSize:10, color:'var(--ink-3)', letterSpacing:2, fontFamily:'var(--mono)'}}>TOKEN NO.</div>
                <div style={{fontSize:44, fontWeight:800, color:'var(--navy)', fontFamily:'var(--mono)', letterSpacing:-1, lineHeight:1}}>{t.tokenNo}</div>
                <div style={{fontSize:11, color:'var(--ink-3)', marginTop:2}}>टोकन संख्या</div>
              </div>
              <div style={{padding:8, background:'#fff', border:'1px solid var(--line)', borderRadius:4}}>
                <FakeQR text={t.id} size={130}/>
              </div>
              <div style={{textAlign:'center'}}>
                <div style={{fontSize:10, color:'var(--ink-3)', letterSpacing:1, fontFamily:'var(--mono)'}}>SCAN AT GATE</div>
                <div style={{fontSize:11, color:'var(--ink-3)'}}>गेट पर स्कैन करें</div>
              </div>
            </div>
          </div>

          {/* Barcode footer */}
          <div style={{background:'#fff', borderRadius:'0 0 12px 12px', marginTop:-12, padding:'20px 24px 16px', borderTop:'1px dashed var(--line)', boxShadow:'0 20px 50px rgba(15,23,42,.15)'}}>
            <div style={{fontFamily:'var(--mono)', fontSize:10, letterSpacing:1, color:'var(--ink-3)', marginBottom:6}}>*{t.id.replace(/-/g,'')}*{Date.now().toString(36).toUpperCase()}*</div>
            <svg width="100%" height="34" viewBox="0 0 500 34">
              {Array.from({length:80}).map((_,i)=>{
                const w = [1,1,2,3,2,1,3,2][i%8];
                const x = i * 6;
                return <rect key={i} x={x} y={0} width={w} height={34} fill="#0f172a"/>;
              })}
            </svg>
          </div>
        </div>

        {/* Queue status card */}
        <div className="vstack" style={{gap:16}}>
          <div className="card">
            <div className="card-header">
              <h3>🔴 Live Queue · वर्तमान कतार</h3>
              <span className="chip chip-green"><span style={{width:6,height:6,borderRadius:'50%',background:'var(--green)',animation:'pulse 2s infinite'}}/> Updating</span>
            </div>
            <div className="card-body">
              <div style={{textAlign:'center', padding:'8px 0 16px'}}>
                <div style={{fontSize:12, color:'var(--ink-3)', textTransform:'uppercase', letterSpacing:.5}}>Your position · आपका स्थान</div>
                <div style={{fontSize:80, fontWeight:800, color:'var(--saffron)', fontFamily:'var(--mono)', lineHeight:1, marginTop:4}}>
                  #{queuePos}
                </div>
                <div style={{fontSize:14, color:'var(--ink-2)', marginTop:8}}>of 34 farmers ahead of gate</div>
              </div>

              <div style={{padding:14, background:'var(--navy-3)', borderRadius:6, textAlign:'center', marginBottom:12}}>
                <div style={{fontSize:12, color:'var(--navy)', textTransform:'uppercase', fontWeight:700, letterSpacing:.3}}>Estimated arrival window</div>
                <div style={{fontSize:24, fontWeight:700, color:'var(--navy)', marginTop:4}}>
                  <CountdownETA minutes={queuePos * 6}/>
                </div>
                <div style={{fontSize:12, color:'var(--ink-3)', marginTop:2}}>अनुमानित प्रतीक्षा समय</div>
              </div>

              <div style={{fontSize:13}}>
                <div className="hstack" style={{padding:'8px 0', borderBottom:'1px dashed var(--line)'}}>
                  <span style={{color:'var(--ink-3)'}}>Currently serving</span><span className="spacer"/><span className="mono" style={{fontWeight:700}}>A-{240 - queuePos}</span>
                </div>
                <div className="hstack" style={{padding:'8px 0', borderBottom:'1px dashed var(--line)'}}>
                  <span style={{color:'var(--ink-3)'}}>Avg service time</span><span className="spacer"/><span className="mono" style={{fontWeight:700}}>6 min / farmer</span>
                </div>
                <div className="hstack" style={{padding:'8px 0'}}>
                  <span style={{color:'var(--ink-3)'}}>SMS updates</span><span className="spacer"/><span className="chip chip-green">✓ Enabled</span>
                </div>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-body" style={{padding:16}}>
              <div style={{fontSize:13, fontWeight:700, color:'var(--navy)', marginBottom:10}}>📢 What happens next · आगे क्या होगा</div>
              <div className="vstack" style={{gap:10}}>
                {[
                  ['1', 'You get SMS when #3 in queue', 'कतार में #3 पर SMS आएगा'],
                  ['2', 'Arrive at Gate 2 · scan QR', 'गेट 2 पर QR स्कैन करें'],
                  ['3', 'Quality inspection · weighing', 'गुणवत्ता जाँच · तौल'],
                  ['4', 'DBT to your Aadhaar-linked bank', 'आधार बैंक में DBT भुगतान'],
                ].map(s=>(
                  <div key={s[0]} className="hstack" style={{gap:10, alignItems:'flex-start'}}>
                    <div style={{width:22, height:22, borderRadius:'50%', background:'var(--navy)', color:'#fff', fontSize:11, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0}}>{s[0]}</div>
                    <div style={{fontSize:13}}>
                      <div style={{color:'var(--ink)'}}>{s[1]}</div>
                      <div style={{color:'var(--ink-3)'}}>{s[2]}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { TokenPage });
