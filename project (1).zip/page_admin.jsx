/* State Admin Command Center */

function MiniIndia() {
  return (
    <svg viewBox="0 0 400 460" style={{width:'100%', height:'auto'}}>
      <defs>
        <linearGradient id="heat" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#c1272d"/>
          <stop offset=".5" stopColor="#f5a623"/>
          <stop offset="1" stopColor="#128807"/>
        </linearGradient>
      </defs>
      <rect width="400" height="460" fill="#f6f8fc"/>
      <path d="M 130 60 L 175 55 L 200 70 L 235 65 L 265 85 L 290 105 L 320 115 L 355 135 L 375 160 L 365 200 L 335 225 L 320 260 L 300 285 L 285 315 L 270 340 L 255 370 L 235 395 L 210 410 L 185 415 L 165 400 L 155 375 L 145 345 L 130 315 L 115 285 L 100 250 L 90 215 L 95 180 L 105 145 L 115 110 L 130 60 Z" fill="#e8eef8" stroke="var(--navy)" strokeWidth="1.5"/>

      {typeof MANDI_DOTS !== 'undefined' && MANDI_DOTS.map(m => {
        const r = 4 + m.load * 8;
        return (
          <g key={m.id}>
            <circle cx={m.x} cy={m.y} r={r+4} fill={m.load>=0.75?'var(--red)':m.load>=0.45?'var(--amber)':m.load>0?'var(--green)':'#94a3b8'} opacity="0.2"/>
            <circle cx={m.x} cy={m.y} r={r} fill={m.load>=0.75?'var(--red)':m.load>=0.45?'var(--amber)':m.load>0?'var(--green)':'#94a3b8'} stroke="#fff" strokeWidth="1.5"/>
          </g>
        );
      })}
    </svg>
  );
}

function BarChart({ data, height = 180, color = 'var(--navy)' }) {
  const max = Math.max(...data.map(d => d.v));
  return (
    <svg viewBox={`0 0 ${data.length * 46} ${height}`} style={{width:'100%', height, display:'block'}}>
      {data.map((d,i)=>{
        const h = (d.v / max) * (height - 34);
        return (
          <g key={i}>
            <rect x={i*46 + 8} y={height - 22 - h} width="30" height={h} fill={color} rx="2" opacity="0.85"/>
            <text x={i*46 + 23} y={height - 8} textAnchor="middle" fontSize="10" fill="var(--ink-3)">{d.l}</text>
            <text x={i*46 + 23} y={height - 26 - h} textAnchor="middle" fontSize="9" fill="var(--ink-2)" fontWeight="600">{d.v}</text>
          </g>
        );
      })}
    </svg>
  );
}

function LineChart({ points, height = 180 }) {
  const w = 400;
  const max = Math.max(...points);
  const min = Math.min(...points);
  const range = max - min || 1;
  const step = w / (points.length - 1);
  const path = points.map((p,i)=> `${i===0?'M':'L'} ${i*step} ${height - 20 - ((p-min)/range) * (height - 40)}`).join(' ');
  const area = `${path} L ${w} ${height-20} L 0 ${height-20} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${height}`} style={{width:'100%', height, display:'block'}}>
      <defs>
        <linearGradient id="lgrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="var(--navy)" stopOpacity="0.3"/>
          <stop offset="1" stopColor="var(--navy)" stopOpacity="0"/>
        </linearGradient>
      </defs>
      {[0.25,0.5,0.75].map(f=>(<line key={f} x1="0" y1={height*f} x2={w} y2={height*f} stroke="#e8ecf2" strokeDasharray="2 3"/>))}
      <path d={area} fill="url(#lgrad)"/>
      <path d={path} stroke="var(--navy)" strokeWidth="2.5" fill="none"/>
      {points.map((p,i)=>(<circle key={i} cx={i*step} cy={height - 20 - ((p-min)/range) * (height - 40)} r="3" fill="var(--saffron)" stroke="#fff" strokeWidth="1.5"/>))}
    </svg>
  );
}

function LiveFeed() {
  const [items, setItems] = useState([
    { t:'09:42', k:'token',  m:'Token A-247 issued · Ramesh Kumar · Khanna Mandi' },
    { t:'09:41', k:'dbt',    m:'₹60,625 DBT settled to Baldev Singh · SBI ****4782' },
    { t:'09:40', k:'accept', m:'32 qtl Wheat accepted · Grade FAQ · Karnal Mandi' },
    { t:'09:39', k:'flag',   m:'AgriStack blocked slot #A-249 — land mismatch' },
    { t:'09:38', k:'voice',  m:'Bhashini: Punjabi query resolved in 1.2s · Ludhiana' },
    { t:'09:37', k:'ivr',    m:'IVR booking · missed call from +91-98XXX-5521' },
  ]);
  useEffect(() => {
    const events = [
      { k:'token',  m:'Token A-2%N issued · Bhopal Mandi'},
      { k:'accept', m:'%N qtl Paddy accepted · Erode Mandi'},
      { k:'dbt',    m:'₹%NK DBT settled · HDFC Bank'},
      { k:'voice',  m:'Bhashini: Tamil query · %Ns response'},
      { k:'flag',   m:'AgriStack alert: duplicate Aadhaar attempt blocked'},
      { k:'ivr',    m:'SMS token delivered to +91-XXX-XX-%N'},
    ];
    const iv = setInterval(() => {
      const e = events[Math.floor(Math.random()*events.length)];
      const now = new Date();
      const t = String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');
      const m = e.m.replace('%N', Math.floor(Math.random()*90)+10).replace('%N', Math.floor(Math.random()*90)+10);
      setItems(prev => [{ t, k:e.k, m }, ...prev.slice(0,9)]);
    }, 3200);
    return () => clearInterval(iv);
  }, []);
  const colors = { token:'var(--navy)', dbt:'var(--green)', accept:'var(--green)', flag:'var(--red)', voice:'var(--saffron)', ivr:'#7c3aed' };
  return (
    <div style={{maxHeight:340, overflow:'hidden'}}>
      {items.map((x,i)=>(
        <div key={i} style={{display:'flex', gap:10, padding:'8px 0', borderBottom:'1px dashed var(--line-2)', fontSize:13, animation: i===0?'slideDown .4s':'none'}}>
          <span className="mono" style={{color:'var(--ink-3)', fontSize:11, width:38, flexShrink:0}}>{x.t}</span>
          <span style={{width:6, height:6, borderRadius:'50%', background:colors[x.k], marginTop:6, flexShrink:0}}/>
          <span style={{color:'var(--ink-2)'}}>{x.m}</span>
        </div>
      ))}
      <style>{`@keyframes slideDown { from{opacity:0; transform:translateY(-4px)} to{opacity:1; transform:translateY(0)} }`}</style>
    </div>
  );
}

function AdminDashboard() {
  const [range, setRange] = useState('today');

  return (
    <div className="page">
      <div className="page-title">
        <div>
          <h2>State Command Centre · राज्य कमांड सेंटर</h2>
          <div className="hindi">जिलेवार बुद्धिमत्ता · केंद्र उपयोग · प्रवाह विश्लेषण</div>
          <div className="sub">District intelligence · Centre utilisation · Throughput analytics</div>
        </div>
        <div className="hstack" style={{gap:8}}>
          {['today','week','month','season'].map(r=>(
            <button key={r} onClick={()=>setRange(r)}
              className={'btn ' + (range===r?'btn-outline':'')}
              style={{padding:'8px 14px', fontSize:13, background: range===r?'var(--navy)':'#fff', color: range===r?'#fff':'var(--ink-2)', border:'1px solid ' + (range===r?'var(--navy)':'var(--line)'), borderRadius:6}}>
              {r === 'today'?'Today · आज': r==='week'?'This week · इस सप्ताह': r==='month'?'This month · इस माह':'Season · रबी सीज़न'}
            </button>
          ))}
          <button className="btn btn-outline" style={{marginLeft:8}}>📥 Export CSV</button>
        </div>
      </div>

      {/* KPI row */}
      <div className="grid" style={{gridTemplateColumns:'repeat(5,1fr)', gap:14, marginBottom:20}}>
        <div className="kpi"><div className="label">Farmers served</div><div className="value tabular">47,823</div><div className="delta">▲ 12.4% vs last week</div></div>
        <div className="kpi k-green"><div className="label">Quintals procured</div><div className="value tabular">8.92 L</div><div className="delta">▲ 18.2%</div></div>
        <div className="kpi k-saffron"><div className="label">DBT settled</div><div className="value tabular">₹1,247 Cr</div><div className="delta">Avg 3h 42m</div></div>
        <div className="kpi"><div className="label">Avg wait time</div><div className="value">14 <span style={{fontSize:14}}>min</span></div><div className="delta">▼ 68% vs legacy</div></div>
        <div className="kpi k-red"><div className="label">Fraud blocked</div><div className="value tabular">1,247</div><div className="hi">AgriStack land-record</div></div>
      </div>

      {/* Map + Live feed */}
      <div className="grid" style={{gridTemplateColumns:'1.6fr 1fr', gap:20, marginBottom:20}}>
        <div className="card">
          <div className="card-header">
            <h3>🗺️ Nation-wide Load · देशव्यापी भार</h3>
            <span className="chip chip-green"><span style={{width:6,height:6,borderRadius:'50%',background:'var(--green)',animation:'pulse 2s infinite'}}/> Live</span>
          </div>
          <div className="card-body" style={{padding:12}}>
            <div className="grid" style={{gridTemplateColumns:'1fr 1fr', gap:12}}>
              <MiniIndia />
              <div>
                <div style={{fontSize:12, textTransform:'uppercase', color:'var(--ink-3)', fontWeight:700, letterSpacing:.4, marginBottom:8}}>Top 5 pressure points</div>
                {[
                  ['Ludhiana, Punjab',   92,'var(--red)'],
                  ['Karnal, Haryana',    78,'var(--amber)'],
                  ['Nashik, Maharashtra',72,'var(--amber)'],
                  ['Lucknow, UP',        65,'var(--amber)'],
                  ['Guntur, AP',         58,'var(--amber)'],
                ].map(([n,v,c])=>(
                  <div key={n} style={{marginBottom:10}}>
                    <div className="hstack" style={{fontSize:12, marginBottom:4}}>
                      <span style={{fontWeight:600, color:'var(--ink-2)'}}>{n}</span>
                      <span className="spacer"/>
                      <span className="tabular" style={{color:c, fontWeight:700}}>{v}%</span>
                    </div>
                    <div style={{height:6, background:'#eef2f9', borderRadius:3, overflow:'hidden'}}>
                      <div style={{width:v+'%', height:'100%', background:c, borderRadius:3}}/>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3>⚡ Live Event Feed · वास्तविक-समय गतिविधि</h3>
            <span className="chip chip-green">streaming</span>
          </div>
          <div className="card-body">
            <LiveFeed />
          </div>
        </div>
      </div>

      {/* Charts row */}
      <div className="grid grid-2" style={{gap:20, marginBottom:20}}>
        <div className="card">
          <div className="card-header">
            <h3>📈 Hourly throughput · घंटा-दर-घंटा प्रवाह</h3>
            <span className="hi">Farmers processed / hour</span>
          </div>
          <div className="card-body">
            <LineChart points={[820, 1240, 2180, 3420, 4680, 5240, 5820, 5240, 4820, 4120, 3240, 1820]}/>
            <div className="hstack" style={{fontSize:11, color:'var(--ink-3)', marginTop:6, paddingLeft:4, paddingRight:4}}>
              <span>8AM</span><span className="spacer"/><span>12PM</span><span className="spacer"/><span>4PM</span><span className="spacer"/><span>8PM</span>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3>🌾 Crop split · फसल विभाजन</h3>
            <span className="hi">Quintals · today</span>
          </div>
          <div className="card-body">
            <BarChart data={[
              { l:'Wheat',   v: 4820 },
              { l:'Paddy',   v: 2140 },
              { l:'Mustard', v: 1120 },
              { l:'Gram',    v: 660 },
              { l:'Bajra',   v: 340 },
              { l:'Maize',   v: 220 },
            ]} color="var(--saffron)"/>
          </div>
        </div>
      </div>

      {/* Fraud alerts + District table */}
      <div className="grid" style={{gridTemplateColumns:'1fr 1.5fr', gap:20}}>

        <div className="card" style={{borderTop:'3px solid var(--red)'}}>
          <div className="card-header">
            <h3>🛡️ AgriStack Fraud Alerts · धोखाधड़ी सतर्कता</h3>
            <span className="chip chip-red">6 open</span>
          </div>
          <div className="card-body" style={{padding:0}}>
            {[
              { sev:'HIGH',   who:'Aadhaar ****7823 · Kota',    what:'Booked 12 tokens across 4 mandis · 148 qtl declared vs 0.6 ha holding' },
              { sev:'HIGH',   who:'Aadhaar ****4451 · Ludhiana', what:'Vehicle PB-10-CG-2201 registered for 3 different farmers today' },
              { sev:'MEDIUM', who:'Aadhaar ****9902 · Nashik',   what:'Weight declared 84 qtl · avg for 1.2 ha land: 22 qtl' },
              { sev:'MEDIUM', who:'Trader ID T-4471 · Guntur',   what:'Attempted booking under farmer Aadhaar · relationship not verified' },
            ].map((a,i)=>(
              <div key={i} style={{padding:'12px 16px', borderBottom: i<3?'1px solid var(--line-2)':'none'}}>
                <div className="hstack" style={{marginBottom:4}}>
                  <span className={'chip ' + (a.sev==='HIGH'?'chip-red':'chip-amber')}>{a.sev}</span>
                  <span style={{fontSize:12, color:'var(--ink-3)', fontFamily:'var(--mono)', marginLeft:8}}>{a.who}</span>
                </div>
                <div style={{fontSize:13, color:'var(--ink-2)', lineHeight:1.5}}>{a.what}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3>🏛️ District Breakdown · जिलेवार सारांश</h3>
          </div>
          <div className="card-body" style={{padding:0}}>
            <table className="gov-table">
              <thead>
                <tr>
                  <th>District</th>
                  <th>Mandis</th>
                  <th>Farmers</th>
                  <th>Qtl</th>
                  <th>Utilisation</th>
                  <th>Avg Wait</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Ludhiana, PB',   14, 3820, '84,220', 92, '18 m'],
                  ['Karnal, HR',      9, 2140, '58,140', 78, '15 m'],
                  ['Bhopal, MP',     11, 1820, '42,880', 62, '12 m'],
                  ['Lucknow, UP',    22, 4120, '82,640', 68, '22 m'],
                  ['Nashik, MH',     12, 1620, '32,180', 72, '19 m'],
                  ['Kota, RJ',        7,  920, '18,440', 42, '10 m'],
                  ['Guntur, AP',     15, 2680, '48,220', 58, '16 m'],
                ].map((r,i)=>(
                  <tr key={i}>
                    <td style={{fontWeight:600}}>{r[0]}</td>
                    <td className="tabular">{r[1]}</td>
                    <td className="tabular">{r[2].toLocaleString('en-IN')}</td>
                    <td className="tabular">{r[3]}</td>
                    <td>
                      <div className="hstack" style={{gap:8}}>
                        <div style={{width:60, height:6, background:'#eef2f9', borderRadius:3, overflow:'hidden'}}>
                          <div style={{width:r[4]+'%', height:'100%', background: r[4]>=80?'var(--red)':r[4]>=60?'var(--amber)':'var(--green)'}}/>
                        </div>
                        <span className="tabular" style={{fontSize:12, fontWeight:600, width:32}}>{r[4]}%</span>
                      </div>
                    </td>
                    <td className="tabular">{r[5]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { AdminDashboard });
