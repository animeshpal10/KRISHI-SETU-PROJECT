/* Landing page — Live Mandi Status */

const MANDI_DOTS = [
  // Approximate SVG coords on a stylized India outline (viewBox 0 0 400 460)
  { id:'PB', name:'Punjab · Ludhiana',      x:150, y:110, load:0.92, status:'busy'   },
  { id:'HR', name:'Haryana · Karnal',       x:170, y:130, load:0.78, status:'busy'   },
  { id:'UP', name:'UP · Lucknow',           x:215, y:155, load:0.65, status:'open'   },
  { id:'BR', name:'Bihar · Patna',          x:275, y:170, load:0.48, status:'open'   },
  { id:'WB', name:'West Bengal · Burdwan',  x:305, y:200, load:0.55, status:'open'   },
  { id:'MP', name:'MP · Bhopal',            x:180, y:210, load:0.38, status:'open'   },
  { id:'MH', name:'Maharashtra · Nashik',   x:150, y:265, load:0.72, status:'busy'   },
  { id:'GJ', name:'Gujarat · Rajkot',       x:105, y:225, load:0.42, status:'open'   },
  { id:'RJ', name:'Rajasthan · Kota',       x:130, y:175, load:0.31, status:'open'   },
  { id:'KA', name:'Karnataka · Hubli',      x:160, y:320, load:0.22, status:'open'   },
  { id:'AP', name:'Andhra Pradesh · Guntur',x:200, y:340, load:0.58, status:'open'   },
  { id:'TN', name:'Tamil Nadu · Erode',     x:185, y:390, load:0.15, status:'closed' },
  { id:'OD', name:'Odisha · Cuttack',       x:270, y:240, load:0.35, status:'open'   },
  { id:'AS', name:'Assam · Guwahati',       x:355, y:170, load:0.05, status:'closed' },
];

function loadColor(l) {
  if (l >= 0.75) return 'var(--red)';
  if (l >= 0.45) return 'var(--amber)';
  if (l > 0)     return 'var(--green)';
  return 'var(--ink-3)';
}

function IndiaHeatmap({ onHover }) {
  const [hovered, setHovered] = useState(null);
  return (
    <div style={{position:'relative'}}>
      <svg viewBox="0 0 400 460" style={{width:'100%', height:'auto', display:'block'}}>
        <defs>
          <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#e8ecf2" strokeWidth="0.5"/>
          </pattern>
        </defs>
        <rect width="400" height="460" fill="#f6f8fc"/>
        <rect width="400" height="460" fill="url(#grid)"/>
        {/* Stylized India outline (simplified) */}
        <path d="M 130 60 L 175 55 L 200 70 L 235 65 L 265 85 L 290 105 L 320 115 L 355 135 L 375 160 L 365 200 L 335 225 L 320 260 L 300 285 L 285 315 L 270 340 L 255 370 L 235 395 L 210 410 L 185 415 L 165 400 L 155 375 L 145 345 L 130 315 L 115 285 L 100 250 L 90 215 L 95 180 L 105 145 L 115 110 L 130 60 Z"
              fill="#e8eef8" stroke="var(--navy)" strokeWidth="1.5" opacity="0.9"/>
        {/* State dividers hint */}
        <path d="M 130 60 L 200 200 M 200 70 L 260 200 M 290 105 L 250 250 M 165 220 L 300 260 M 155 300 L 265 340" stroke="#c9d3e8" strokeWidth="0.8" strokeDasharray="2 3" fill="none"/>

        {MANDI_DOTS.map(m => {
          const r = 4 + m.load * 8;
          return (
            <g key={m.id} onMouseEnter={()=>{setHovered(m); onHover&&onHover(m);}} onMouseLeave={()=>{setHovered(null); onHover&&onHover(null);}} style={{cursor:'pointer'}}>
              {m.status !== 'closed' && (
                <circle cx={m.x} cy={m.y} r={r+6} fill={loadColor(m.load)} opacity="0.15">
                  <animate attributeName="r" values={`${r+2};${r+10};${r+2}`} dur="2.5s" repeatCount="indefinite"/>
                  <animate attributeName="opacity" values="0.3;0;0.3" dur="2.5s" repeatCount="indefinite"/>
                </circle>
              )}
              <circle cx={m.x} cy={m.y} r={r} fill={loadColor(m.load)} stroke="#fff" strokeWidth="1.5"/>
              {hovered && hovered.id === m.id && (
                <g>
                  <rect x={m.x+10} y={m.y-24} width="130" height="34" rx="4" fill="#0f172a" opacity="0.92"/>
                  <text x={m.x+16} y={m.y-11} fill="#fff" fontSize="10" fontWeight="600">{m.name}</text>
                  <text x={m.x+16} y={m.y+1} fill="#a3bffa" fontSize="9">Load: {Math.round(m.load*100)}% · {m.status.toUpperCase()}</text>
                </g>
              )}
            </g>
          );
        })}
      </svg>
      {/* Legend */}
      <div style={{position:'absolute', bottom:12, left:12, background:'rgba(255,255,255,.95)', border:'1px solid var(--line)', borderRadius:6, padding:'8px 12px', fontSize:11}}>
        <div style={{fontWeight:700, color:'var(--navy)', marginBottom:6, textTransform:'uppercase', letterSpacing:.3}}>Legend · व्याख्या</div>
        <div className="hstack" style={{gap:14, flexWrap:'wrap'}}>
          <span className="hstack" style={{gap:5}}><span style={{width:10,height:10,borderRadius:'50%',background:'var(--green)'}}/> Open · खुला</span>
          <span className="hstack" style={{gap:5}}><span style={{width:10,height:10,borderRadius:'50%',background:'var(--amber)'}}/> Busy · व्यस्त</span>
          <span className="hstack" style={{gap:5}}><span style={{width:10,height:10,borderRadius:'50%',background:'var(--red)'}}/> Peak · भीड़</span>
          <span className="hstack" style={{gap:5}}><span style={{width:10,height:10,borderRadius:'50%',background:'var(--ink-3)'}}/> Closed · बंद</span>
        </div>
      </div>
    </div>
  );
}

// -------- Hero variants (auto-rotating) --------
function HeroA_Map() {
  return (
    <div className="card" style={{height:'100%'}}>
      <div className="card-header">
        <div>
          <h3>🗺️ Live Mandi Heatmap · देशव्यापी मंडी नक्शा</h3>
          <div className="hi" style={{marginTop:2}}>Real-time procurement centre load across India</div>
        </div>
        <span className="chip chip-green"><span style={{width:6,height:6,borderRadius:'50%',background:'var(--green)',animation:'pulse 2s infinite'}}/> Live</span>
      </div>
      <div className="card-body" style={{padding:12}}>
        <IndiaHeatmap />
      </div>
    </div>
  );
}

function LiveCounter({ target, format, prefix='', suffix='' }) {
  const [val, setVal] = useState(target * 0.97);
  useEffect(() => {
    const iv = setInterval(() => {
      setVal(v => {
        const inc = Math.random() * (target * 0.0008) + 0.2;
        return v + inc;
      });
    }, 900);
    return () => clearInterval(iv);
  }, [target]);
  return <span className="tabular">{prefix}{format ? format(val) : Math.floor(val).toLocaleString('en-IN')}{suffix}</span>;
}

function HeroB_Split() {
  return (
    <div className="card" style={{height:'100%', display:'flex', flexDirection:'column'}}>
      <div className="card-header">
        <h3>👨‍🌾 Every farmer, every language, every slot · secured</h3>
      </div>
      <div style={{display:'grid', gridTemplateColumns:'1.2fr 1fr', gap:0, flex:1}}>
        <div style={{padding:22, borderRight:'1px solid var(--line-2)'}}>
          <div style={{fontSize:12, color:'var(--saffron)', fontWeight:700, letterSpacing:.5, textTransform:'uppercase'}}>Voice-First · आवाज़ पहले</div>
          <h2 style={{margin:'8px 0 6px', fontSize:26, color:'var(--navy)', lineHeight:1.2}}>
            Just speak in your language.<br/>We book the mandi slot.
          </h2>
          <div style={{fontSize:16, color:'var(--ink-2)', marginBottom:14}}>अपनी भाषा में बोलिए — बाकी हम संभालेंगे।</div>
          <div className="vstack" style={{gap:8, marginTop:14}}>
            <div className="hstack" style={{gap:10}}><span style={{fontSize:20}}>🎙️</span><span>22 constitutional languages via <b>Bhashini AI</b></span></div>
            <div className="hstack" style={{gap:10}}><span style={{fontSize:20}}>🔒</span><span>Aadhaar + land record verified via <b>AgriStack</b></span></div>
            <div className="hstack" style={{gap:10}}><span style={{fontSize:20}}>💰</span><span>DBT payment tracked live via <b>PFMS</b></span></div>
            <div className="hstack" style={{gap:10}}><span style={{fontSize:20}}>📞</span><span>Feature phone? <b>Missed-call booking · 1800-180-1551</b></span></div>
          </div>
        </div>
        <div style={{background:'linear-gradient(160deg, var(--navy) 0%, #1a4fb0 100%)', color:'#fff', padding:22, display:'flex', flexDirection:'column', justifyContent:'space-between'}}>
          <div>
            <div style={{fontSize:11, textTransform:'uppercase', letterSpacing:.5, opacity:.7}}>Today · आज</div>
            <div style={{fontSize:42, fontWeight:700, marginTop:8, fontVariantNumeric:'tabular-nums'}}>
              <LiveCounter target={47823} />
            </div>
            <div style={{fontSize:13, opacity:.85}}>Farmers served today · आज सेवा किए किसान</div>
          </div>
          <div style={{marginTop:20, paddingTop:16, borderTop:'1px solid rgba(255,255,255,.15)'}}>
            <div style={{fontSize:11, textTransform:'uppercase', letterSpacing:.5, opacity:.7}}>Avg wait time · औसत प्रतीक्षा</div>
            <div style={{fontSize:28, fontWeight:700, marginTop:4, fontVariantNumeric:'tabular-nums'}}>
              14 <span style={{fontSize:16, opacity:.7}}>min</span>
              <span style={{fontSize:12, marginLeft:10, color:'var(--saffron-2)', fontWeight:600}}>↓ 68% vs legacy</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function HeroC_Stats() {
  return (
    <div className="card" style={{height:'100%'}}>
      <div className="card-header">
        <h3>📊 National Procurement Pulse · राष्ट्रीय अधिप्राप्ति नब्ज़</h3>
        <span className="chip chip-green"><span style={{width:6,height:6,borderRadius:'50%',background:'var(--green)',animation:'pulse 2s infinite'}}/> Streaming</span>
      </div>
      <div className="card-body" style={{padding:0}}>
        <div className="grid grid-2" style={{gap:0}}>
          {[
            {l:'Farmers served today', hi:'किसान सेवित', v: <LiveCounter target={47823}/>, sub:'▲ 12% vs yesterday', c:'var(--green)'},
            {l:'Quintals procured',    hi:'क्विंटल खरीदा',   v: <LiveCounter target={892456}/>, sub:'Wheat, Paddy, Mustard, Gram', c:'var(--navy)'},
            {l:'DBT settled (₹ Cr)',   hi:'DBT भुगतान (₹ करोड़)', v: <LiveCounter target={1247} format={v=>'₹'+v.toFixed(1)+' Cr'} />, sub:'Avg settlement · 3h 42m', c:'var(--saffron)'},
            {l:'Avg wait time',        hi:'औसत प्रतीक्षा',   v: '14 min', sub:'▼ 68% vs legacy queue', c:'var(--red)'},
          ].map((s,i)=>(
            <div key={i} style={{padding:'22px 20px', borderRight: i%2===0?'1px solid var(--line-2)':'none', borderBottom: i<2?'1px solid var(--line-2)':'none'}}>
              <div style={{fontSize:11, textTransform:'uppercase', letterSpacing:.4, color:'var(--ink-3)', fontWeight:700}}>{s.l}</div>
              <div style={{fontSize:12, color:'var(--ink-3)'}}>{s.hi}</div>
              <div style={{fontSize:32, fontWeight:700, color:s.c, marginTop:6, fontVariantNumeric:'tabular-nums'}}>{s.v}</div>
              <div style={{fontSize:12, color:'var(--ink-2)', marginTop:4}}>{s.sub}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Auto-rotating hero
function RotatingHero() {
  const [idx, setIdx] = useState(0);
  const heroes = [<HeroA_Map />, <HeroB_Split />, <HeroC_Stats />];
  const titles = ['Live Heatmap', 'Voice-First Story', 'National Pulse'];
  useEffect(() => {
    const iv = setInterval(() => setIdx(i => (i+1) % 3), 8000);
    return () => clearInterval(iv);
  }, []);
  return (
    <div>
      <div className="hstack" style={{marginBottom:10, gap:8}}>
        {titles.map((t,i)=>(
          <button key={i}
                  onClick={()=>setIdx(i)}
                  style={{
                    padding:'6px 12px', fontSize:12, fontWeight:600,
                    background: idx===i ? 'var(--navy)' : '#fff',
                    color: idx===i ? '#fff' : 'var(--ink-2)',
                    border:'1px solid ' + (idx===i ? 'var(--navy)' : 'var(--line)'),
                    borderRadius:20
                  }}>
            {i+1}. {t}
          </button>
        ))}
        <span className="spacer" />
        <span className="small muted">Auto-rotating · अपने आप बदल रहा</span>
      </div>
      {heroes[idx]}
    </div>
  );
}

// -------- Ticker --------
function ScrollingTicker() {
  const items = [
    '🌾 Wheat MSP 2026-27: ₹2,425/quintal',
    '🎫 Ludhiana Mandi: 234 tokens issued in last hour',
    '💰 ₹127 Cr DBT settled since 9:00 AM',
    '📢 Bhopal Mandi opens Gate-3 for Mustard procurement',
    '⚠️ Karnal Mandi at 92% capacity — book afternoon slot',
    '🌱 Paddy MSP 2026-27: ₹2,300/quintal (Common)',
    '📞 Feature-phone farmers: dial 1800-180-1551 for token',
    '🛡️ AgriStack blocked 43 duplicate slot attempts today',
  ];
  return (
    <div style={{background:'var(--navy)', color:'#fff', padding:'10px 0', overflow:'hidden', position:'relative'}}>
      <div className="wrap" style={{maxWidth:1400, margin:'0 auto', padding:'0 24px', display:'flex', alignItems:'center', gap:16}}>
        <span className="chip" style={{background:'var(--saffron)', color:'#3a2100', borderColor:'var(--saffron)', flexShrink:0, fontWeight:700}}>📢 LIVE UPDATES</span>
        <div style={{overflow:'hidden', flex:1}}>
          <div style={{display:'inline-flex', gap:48, animation:'scroll-x 60s linear infinite', whiteSpace:'nowrap', fontSize:14}}>
            {[...items, ...items].map((t,i)=>(<span key={i} style={{color:'#e8eef8'}}>{t}</span>))}
          </div>
        </div>
      </div>
      <style>{`@keyframes scroll-x { from{transform:translateX(0)} to{transform:translateX(-50%)} }`}</style>
    </div>
  );
}

// -------- CTA row --------
function CtaRow({ navigate }) {
  const cards = [
    { icon:'🎙️', title:'Book a Slot',    hi:'स्लॉट बुक करें', desc:'Speak in your language — we book instantly', cta:'Start Booking', path:'/farmer', bg:'linear-gradient(135deg, #0b3d91, #1a4fb0)', color:'#fff', accent:'var(--saffron)'},
    { icon:'📍', title:'Track My Crop',  hi:'फसल ट्रैक करें',  desc:'Arrival → Quality → Weight → DBT payment', cta:'Track Now', path:'/track', bg:'#fff', color:'var(--ink)', accent:'var(--green)'},
    { icon:'📞', title:'No Smartphone?', hi:'फीचर फ़ोन?',      desc:'Missed-call booking · SMS token delivery',  cta:'Call 1800-180-1551', path:'/', bg:'linear-gradient(135deg, var(--saffron), #ff7f2a)', color:'#3a2100', accent:'var(--navy)'},
  ];
  return (
    <div className="grid grid-3" style={{marginTop:24}}>
      {cards.map((c,i)=>(
        <div key={i} style={{
          background:c.bg, color:c.color, padding:24, borderRadius:'var(--radius)',
          border:'1px solid var(--line)', boxShadow:'var(--shadow-sm)',
          display:'flex', flexDirection:'column', gap:8, minHeight:200,
        }}>
          <div style={{fontSize:36}}>{c.icon}</div>
          <div style={{fontSize:20, fontWeight:700}}>{c.title}</div>
          <div style={{fontSize:15, opacity:.85}}>{c.hi}</div>
          <div style={{fontSize:14, opacity:.8, marginTop:4, flex:1}}>{c.desc}</div>
          <button
            onClick={()=>navigate(c.path)}
            style={{
              marginTop:12, padding:'12px 16px',
              background:c.accent, color: c.accent==='var(--saffron)'?'#3a2100':'#fff',
              border:'none', borderRadius:6, fontWeight:700, fontSize:14, cursor:'pointer',
              display:'inline-flex', alignItems:'center', gap:8, justifyContent:'center'
            }}>
            {c.cta} →
          </button>
        </div>
      ))}
    </div>
  );
}

// -------- Transparency block --------
function TransparencyBlock() {
  return (
    <div className="card" style={{marginTop:24}}>
      <div className="card-header">
        <h3>🔍 Public Transparency Dashboard · सार्वजनिक पारदर्शिता</h3>
        <span className="hi">Updated every 60 seconds</span>
      </div>
      <div className="card-body">
        <div className="grid grid-4">
          <div className="kpi">
            <div className="label">Slots issued today</div>
            <div className="value tabular"><LiveCounter target={54200} /></div>
            <div className="hi">कुल स्लॉट जारी</div>
          </div>
          <div className="kpi k-green">
            <div className="label">Fraud attempts blocked</div>
            <div className="value tabular" style={{color:'var(--green)'}}>1,247</div>
            <div className="hi">AgriStack land-record check</div>
          </div>
          <div className="kpi k-saffron">
            <div className="label">Bhashini queries served</div>
            <div className="value tabular"><LiveCounter target={128944} /></div>
            <div className="hi">22 languages · वाणी अनुवाद</div>
          </div>
          <div className="kpi k-red">
            <div className="label">Grievances (last 24h)</div>
            <div className="value tabular">83</div>
            <div className="delta">▲ resolved: 79 (95%)</div>
          </div>
        </div>

        <table className="gov-table" style={{marginTop:20}}>
          <thead>
            <tr>
              <th>State</th>
              <th>Active Mandis</th>
              <th>Farmers Served</th>
              <th>Quintals Procured</th>
              <th>Avg Wait</th>
              <th>DBT Settled</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {[
              ['Punjab · पंजाब',        142, 8942, '184,220', '18 min', '₹247 Cr', 'busy'],
              ['Haryana · हरियाणा',      98,  6127, '128,540', '15 min', '₹172 Cr', 'busy'],
              ['Uttar Pradesh · उ.प्र.', 287, 12480, '256,880', '22 min', '₹341 Cr', 'open'],
              ['Madhya Pradesh · म.प्र.',176, 7823, '162,140', '12 min', '₹218 Cr', 'open'],
              ['Maharashtra · महाराष्ट्र',163, 5942, '108,220', '19 min', '₹142 Cr', 'busy'],
            ].map((r,i)=>(
              <tr key={i}>
                <td style={{fontWeight:600}}>{r[0]}</td>
                <td className="tabular">{r[1]}</td>
                <td className="tabular">{r[2].toLocaleString('en-IN')}</td>
                <td className="tabular">{r[3]}</td>
                <td className="tabular">{r[4]}</td>
                <td className="tabular" style={{fontWeight:600, color:'var(--green)'}}>{r[5]}</td>
                <td><span className={'chip ' + (r[6]==='busy'?'chip-amber':'chip-green')}>{r[6].toUpperCase()}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function LandingPage({ navigate }) {
  return (
    <>
      <ScrollingTicker />
      <div className="page">
        <div className="page-title">
          <div>
            <h2>Live Mandi Status · मंडी की वर्तमान स्थिति</h2>
            <div className="hindi">देश की हर मंडी का पारदर्शी, वास्तविक-समय दृश्य</div>
            <div className="sub">Transparent, real-time view of every procurement centre across India</div>
          </div>
          <div className="hstack" style={{gap:10}}>
            <button className="btn btn-outline" onClick={()=>navigate('/track')}>📍 Track a Token</button>
            <button className="btn btn-saffron btn-lg" onClick={()=>navigate('/farmer')}>🎙️ Book Slot Now</button>
          </div>
        </div>

        <RotatingHero />

        <CtaRow navigate={navigate} />

        <TransparencyBlock />

        {/* Why KrishiSetu */}
        <div className="grid grid-3" style={{marginTop:24}}>
          {[
            {n:'01', t:'Voice-first', hi:'आवाज़-प्रथम', d:'A farmer in Punjab and one in Tamil Nadu book the same way — by speaking their mother tongue. Bhashini handles the rest.', c:'var(--saffron)'},
            {n:'02', t:'Trustless', hi:'भरोसेमंद प्रणाली', d:'Row-locked slot booking means one seat cannot be double-sold. AgriStack land verification blocks middleman hoarding.', c:'var(--navy)'},
            {n:'03', t:'Inclusive', hi:'सर्व-सुलभ', d:'Feature-phone farmers get IVR + SMS tokens. No smartphone, no internet, no problem.', c:'var(--green)'},
          ].map((f,i)=>(
            <div key={i} className="card" style={{padding:22}}>
              <div style={{fontFamily:'var(--mono)', fontSize:36, color:f.c, fontWeight:700, letterSpacing:-1}}>{f.n}</div>
              <div style={{fontSize:20, fontWeight:700, color:'var(--navy)', marginTop:6}}>{f.t}</div>
              <div style={{fontSize:14, color:'var(--ink-3)', marginBottom:8}}>{f.hi}</div>
              <div style={{fontSize:14, color:'var(--ink-2)', lineHeight:1.6}}>{f.d}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

Object.assign(window, { LandingPage });
