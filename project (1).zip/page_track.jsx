/* Track Page — vertical lifecycle timeline with PFMS DBT */

const LIFECYCLE = [
  { id:'arrival',    label:'Mandi Arrival',        hi:'मंडी में आगमन',      icon:'🚜', desc:'QR scanned at gate — token verified' },
  { id:'inspection', label:'Quality Inspection',   hi:'गुणवत्ता जाँच',      icon:'🔍', desc:'FAQ grading — moisture, foreign matter, damage' },
  { id:'weighing',   label:'Weight Verification',  hi:'तौल सत्यापन',         icon:'⚖️', desc:'Electronic weighbridge · sealed reading' },
  { id:'acceptance', label:'Crop Acceptance',      hi:'फसल स्वीकृति',       icon:'✅', desc:'Officer accepts consignment · e-receipt issued' },
  { id:'dbt',        label:'DBT Payment Settled',  hi:'DBT भुगतान',         icon:'💰', desc:'PFMS routes payment to Aadhaar-linked bank' },
];

function TrackPage({ navigate }) {
  const [currentStep, setCurrentStep] = useState(2); // 0..4, currently at Weighing
  const [dbtPercent, setDbtPercent] = useState(0);

  // Auto-advance to feel "live"
  useEffect(() => {
    const iv = setInterval(() => {
      setCurrentStep(s => {
        if (s < LIFECYCLE.length - 1) return s + 1;
        return s;
      });
    }, 8000);
    return () => clearInterval(iv);
  }, []);

  // DBT progress bar simulation
  useEffect(() => {
    if (currentStep >= 4) {
      const iv = setInterval(() => setDbtPercent(p => Math.min(100, p + 4)), 250);
      return () => clearInterval(iv);
    }
  }, [currentStep]);

  const t = (typeof getToken === 'function') ? getToken() : { farmer:'Ramesh Kumar', tokenNo:'A-247', weight:'25', cropObj:{name:'Wheat', hi:'गेहूं', msp:'₹2,425/qtl'}, mandi:'Khanna Mandi, Ludhiana', aadhaar:'XXXX-XXXX-4782' };
  const totalAmount = (parseInt(t.weight || 25) * 2425);

  return (
    <div className="page">
      <div className="page-title">
        <div>
          <h2>Live Crop Tracking · फसल की स्थिति</h2>
          <div className="hindi">आगमन से भुगतान तक — हर कदम दिखेगा</div>
          <div className="sub">Real-time lifecycle from mandi arrival to DBT payment settlement</div>
        </div>
        <div className="hstack" style={{gap:10}}>
          <button className="btn btn-outline" onClick={()=>navigate('/token')}>🎫 View Token</button>
          <button className="btn btn-outline">📥 Download e-Receipt</button>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:'1.4fr 1fr', gap:24}}>

        {/* Timeline */}
        <div className="card">
          <div className="card-header">
            <h3>📍 Consignment Lifecycle · खेप की यात्रा</h3>
            <span className="chip chip-navy mono">Token {t.tokenNo}</span>
          </div>
          <div className="card-body" style={{padding:'20px 24px'}}>
            <div style={{position:'relative', paddingLeft:12}}>
              {LIFECYCLE.map((step, i) => {
                const done = i < currentStep;
                const active = i === currentStep;
                const pending = i > currentStep;
                return (
                  <div key={step.id} style={{display:'flex', gap:18, paddingBottom: i === LIFECYCLE.length-1 ? 0 : 28, position:'relative'}}>
                    {/* Connector line */}
                    {i < LIFECYCLE.length - 1 && (
                      <div style={{
                        position:'absolute', left: 21, top: 44, bottom: 0, width: 3,
                        background: done ? 'var(--green)' : 'var(--line)',
                        borderRadius: 2
                      }}/>
                    )}
                    {/* Dot */}
                    <div style={{
                      width:44, height:44, borderRadius:'50%', flexShrink:0,
                      background: done ? 'var(--green)' : active ? '#fff' : '#fff',
                      border: '3px solid ' + (done ? 'var(--green)' : active ? 'var(--saffron)' : 'var(--line)'),
                      display:'flex', alignItems:'center', justifyContent:'center',
                      fontSize: 20, position:'relative', zIndex:1,
                      boxShadow: active ? '0 0 0 6px rgba(255,153,51,.2)' : 'none',
                      animation: active ? 'glowPulse 2s infinite' : 'none',
                    }}>
                      {done ? <span style={{color:'#fff', fontSize:20, fontWeight:700}}>✓</span> : step.icon}
                    </div>
                    {/* Content */}
                    <div style={{flex:1, paddingTop:2}}>
                      <div className="hstack" style={{gap:10, flexWrap:'wrap'}}>
                        <div style={{fontSize:17, fontWeight:700, color: pending ? 'var(--ink-3)' : 'var(--navy)'}}>
                          {step.label}
                        </div>
                        <div style={{fontSize:14, color:'var(--ink-3)'}}>{step.hi}</div>
                        {done && <span className="chip chip-green">✓ Completed</span>}
                        {active && <span className="chip chip-amber">⏱ In progress · अभी हो रहा है</span>}
                        {pending && <span className="chip chip-gray">Pending</span>}
                      </div>
                      <div style={{fontSize:13, color:'var(--ink-3)', marginTop:4}}>{step.desc}</div>

                      {/* Extra info per step */}
                      {step.id === 'arrival' && done && (
                        <div style={{fontSize:12, color:'var(--ink-3)', marginTop:6, fontFamily:'var(--mono)'}}>
                          09:14 IST · Gate 2 · Officer: Jasbir Singh
                        </div>
                      )}
                      {step.id === 'inspection' && done && (
                        <div style={{marginTop:8, display:'flex', gap:8, flexWrap:'wrap'}}>
                          <span className="chip chip-green">Grade: FAQ</span>
                          <span className="chip chip-navy">Moisture: 11.2%</span>
                          <span className="chip chip-navy">Foreign matter: 0.4%</span>
                        </div>
                      )}
                      {step.id === 'weighing' && active && (
                        <div style={{marginTop:10, padding:14, background:'#fef9f0', border:'1.5px solid var(--saffron)', borderRadius:8}}>
                          <div className="hstack">
                            <div>
                              <div style={{fontSize:11, color:'var(--ink-3)', textTransform:'uppercase', letterSpacing:.4}}>Weighbridge Reading</div>
                              <div style={{fontSize:32, fontWeight:800, color:'var(--navy)', fontFamily:'var(--mono)', marginTop:2}}>
                                <LiveWeightReading target={parseInt(t.weight || 25)}/>
                                <span style={{fontSize:16, color:'var(--ink-3)', marginLeft:6}}>qtl</span>
                              </div>
                            </div>
                            <div className="spacer"/>
                            <div style={{width:64, height:64, borderRadius:8, background:'#0f172a', color:'#4ade80', fontFamily:'var(--mono)', fontSize:22, display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700, boxShadow:'inset 0 2px 8px rgba(0,0,0,.5)'}}>
                              <span style={{animation:'blink 1s infinite'}}>◉</span>
                            </div>
                          </div>
                        </div>
                      )}
                      {step.id === 'acceptance' && done && (
                        <div style={{fontSize:12, color:'var(--ink-3)', marginTop:6, fontFamily:'var(--mono)'}}>
                          e-Receipt: KS-ER-{Date.now().toString(36).toUpperCase().slice(-6)} · Digitally signed
                        </div>
                      )}
                      {step.id === 'dbt' && active && (
                        <div style={{marginTop:10, padding:14, background:'var(--green-3)', border:'1.5px solid var(--green)', borderRadius:8}}>
                          <div className="hstack" style={{marginBottom:8}}>
                            <span style={{fontSize:13, fontWeight:700, color:'var(--green)'}}>PFMS routing payment...</span>
                            <span className="spacer"/>
                            <span style={{fontSize:18, fontWeight:700, color:'var(--green)', fontFamily:'var(--mono)'}}>{dbtPercent}%</span>
                          </div>
                          <div style={{height:8, background:'#fff', borderRadius:4, overflow:'hidden'}}>
                            <div style={{width:`${dbtPercent}%`, height:'100%', background:'var(--green)', transition:'width .25s'}}/>
                          </div>
                          <div style={{fontSize:11, color:'var(--ink-2)', marginTop:8, fontFamily:'var(--mono)'}}>
                            SBI · A/C ****4782 · UTR pending · ETA 3h 42m
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right side: Consignment summary + PFMS timeline */}
        <div className="vstack" style={{gap:16}}>
          <div className="card">
            <div className="card-header">
              <h3>📋 Consignment · खेप विवरण</h3>
            </div>
            <div className="card-body" style={{padding:0}}>
              {[
                ['Farmer', 'किसान', t.farmer],
                ['Aadhaar', 'आधार', t.aadhaar],
                ['Crop', 'फसल', `${t.cropObj?.name} · ${t.cropObj?.hi}`],
                ['Weight', 'भार', `${t.weight} quintals`],
                ['MSP Rate', 'MSP दर', t.cropObj?.msp || '₹2,425/qtl'],
                ['Mandi', 'मंडी', t.mandi],
              ].map((r,i)=>(
                <div key={i} className="hstack" style={{padding:'11px 18px', borderBottom: i<5?'1px solid var(--line-2)':'none', fontSize:14}}>
                  <div>
                    <div style={{fontWeight:600, color:'var(--ink-2)'}}>{r[0]}</div>
                    <div style={{fontSize:12, color:'var(--ink-3)'}}>{r[1]}</div>
                  </div>
                  <div className="spacer"/>
                  <div style={{textAlign:'right', fontWeight:600}}>{r[2]}</div>
                </div>
              ))}
              <div style={{padding:'16px 18px', background:'var(--green-3)', borderTop:'1px solid #b8dbb2'}}>
                <div style={{fontSize:11, color:'var(--green)', fontWeight:700, textTransform:'uppercase', letterSpacing:.4}}>Expected Payment · अनुमानित भुगतान</div>
                <div style={{fontSize:32, fontWeight:800, color:'var(--green)', fontFamily:'var(--mono)', marginTop:4}}>
                  ₹{totalAmount.toLocaleString('en-IN')}
                </div>
                <div style={{fontSize:12, color:'var(--ink-2)'}}>at MSP · Direct to Aadhaar-linked bank</div>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-header">
              <h3>💰 PFMS DBT Timeline · भुगतान समयरेखा</h3>
              <span className="chip chip-navy">Public Financial Mgmt System</span>
            </div>
            <div className="card-body">
              {[
                ['09:14', 'Token issued', 'done'],
                ['10:32', 'Consignment weighed & accepted', 'done'],
                ['10:33', 'e-Receipt digitally signed', 'done'],
                ['10:34', 'PFMS payment request pushed', 'active'],
                ['~14:16', 'DBT credited to SBI ****4782', 'pending'],
                ['~14:17', 'SMS confirmation to +91-XXXXX-4782', 'pending'],
              ].map((r,i)=>(
                <div key={i} className="hstack" style={{gap:10, padding:'8px 0', borderBottom: i<5?'1px dashed var(--line-2)':'none'}}>
                  <div style={{width:8, height:8, borderRadius:'50%', background: r[2]==='done'?'var(--green)':r[2]==='active'?'var(--saffron)':'var(--line)', flexShrink:0, animation: r[2]==='active'?'pulse 2s infinite':''}}/>
                  <span className="mono" style={{fontSize:12, color:'var(--ink-3)', width:52}}>{r[0]}</span>
                  <span style={{fontSize:13, color: r[2]==='pending'?'var(--ink-3)':'var(--ink)', flex:1}}>{r[1]}</span>
                  {r[2]==='done' && <span style={{color:'var(--green)', fontWeight:700, fontSize:14}}>✓</span>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes glowPulse { 0%,100%{box-shadow: 0 0 0 6px rgba(255,153,51,.2)} 50%{box-shadow: 0 0 0 12px rgba(255,153,51,.05)} }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:.3} }
      `}</style>
    </div>
  );
}

function LiveWeightReading({ target }) {
  const [w, setW] = useState(target * 0.85);
  useEffect(() => {
    const iv = setInterval(() => {
      setW(x => {
        const diff = target - x;
        if (Math.abs(diff) < 0.02) return target + (Math.random()-0.5) * 0.1;
        return x + diff * 0.15 + (Math.random()-0.5) * 0.4;
      });
    }, 200);
    return () => clearInterval(iv);
  }, [target]);
  return <span>{w.toFixed(2)}</span>;
}

Object.assign(window, { TrackPage });
