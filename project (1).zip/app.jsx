/* App root */
const { useState: useStateApp } = React;

function App() {
  const [route, navigate] = useRoute();

  const page = (() => {
    switch (route) {
      case '/':        return <LandingPage navigate={navigate}/>;
      case '/farmer':  return <FarmerPortal navigate={navigate}/>;
      case '/token':   return <TokenPage navigate={navigate}/>;
      case '/track':   return <TrackPage navigate={navigate}/>;
      case '/officer': return <OfficerConsole navigate={navigate}/>;
      case '/admin':   return <AdminDashboard navigate={navigate}/>;
      default:         return <LandingPage navigate={navigate}/>;
    }
  })();

  return (
    <>
      <GovHeader route={route} navigate={navigate}/>
      <Breadcrumb route={route}/>
      {page}
      <GovFooter/>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
