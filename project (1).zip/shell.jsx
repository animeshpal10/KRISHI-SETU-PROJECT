/* Shared shell: Top bar, tricolor, header, nav, breadcrumb, footer */
const { useState, useEffect, useRef, useMemo, useCallback } = React;

// -------- Nav definition --------
const NAV_ITEMS = [
  { path: '/',        label: 'Home',            hi: 'मुख पृष्ठ',       icon: '🏠' },
  { path: '/farmer',  label: 'Farmer Portal',   hi: 'किसान पोर्टल',   icon: '👨‍🌾' },
  { path: '/token',   label: 'My Token',        hi: 'मेरा टोकन',      icon: '🎫' },
  { path: '/track',   label: 'Track Status',    hi: 'स्थिति देखें',    icon: '📍' },
  { path: '/officer', label: 'Mandi Officer',   hi: 'मंडी अधिकारी',   icon: '🛡️' },
  { path: '/admin',   label: 'State Admin',     hi: 'राज्य प्रशासन',  icon: '📊' },
];

// -------- Simple hash router --------
function useRoute() {
  const parse = () => {
    const raw = (window.location.hash || '#/').replace(/^#/, '') || '/';
    return raw.split('?')[0];
  };
  const [route, setRoute] = useState(parse);
  useEffect(() => {
    const h = () => setRoute(parse());
    window.addEventListener('hashchange', h);
    return () => window.removeEventListener('hashchange', h);
  }, []);
  const navigate = useCallback((path) => {
    window.location.hash = path;
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);
  return [route, navigate];
}

// -------- Header --------
function GovHeader({ route, navigate }) {
  const [size, setSize] = useState(() => localStorage.getItem('ks_text_size') || 'M');
  useEffect(() => {
    const sizes = { S: '15px', M: '16px', L: '18px' };
    document.documentElement.style.fontSize = sizes[size];
    localStorage.setItem('ks_text_size', size);
  }, [size]);

  return (
    <>
      {/* Utility bar */}
      <div className="gov-topbar">
        <div className="wrap">
          <div className="hstack" style={{gap: 12}}>
            <span>भारत सरकार <span style={{opacity:.6}}>|</span> Government of India</span>
            <span className="divider">•</span>
            <span>Ministry of Agriculture &amp; Farmers Welfare</span>
          </div>
          <div className="hstack" style={{gap: 14}}>
            <a href="#/">Skip to Content</a>
            <span className="divider">|</span>
            <span>Screen Reader</span>
            <span className="divider">|</span>
            <div className="text-size-toggle" title="Text size">
              <button className={size==='S'?'active':''} onClick={()=>setSize('S')}>A-</button>
              <button className={size==='M'?'active':''} onClick={()=>setSize('M')}>A</button>
              <button className={size==='L'?'active':''} onClick={()=>setSize('L')}>A+</button>
            </div>
            <span className="divider">|</span>
            <span>हिंदी | English</span>
          </div>
        </div>
      </div>

      <div className="tricolor-strip" />

      {/* Main header */}
      <header className="gov-header">
        <div className="wrap">
          <div className="emblem" title="Ashoka Emblem">सत्यमेव<br/>जयते</div>
          <div className="brand">
            <h1>KrishiSetu <span style={{color:'var(--saffron)',fontWeight:600}}>· Smart Mandi</span></h1>
            <div className="hindi">कृषिसेतु — स्मार्ट मंडी प्रणाली</div>
            <div className="tagline">Digital India Initiative · National Procurement Platform</div>
          </div>
          <div className="header-meta">
            <span className="badge"><span className="dot"/> LIVE · 2,847 mandis online</span>
            <div style={{textAlign:'right'}}>
              <div style={{fontWeight:600, color:'var(--ink)'}}>Helpline · हेल्पलाइन</div>
              <div style={{fontFamily:'var(--mono)', color:'var(--navy)', fontSize:15, fontWeight:700}}>1800-180-1551</div>
            </div>
          </div>
        </div>
      </header>

      {/* Primary nav */}
      <nav className="gov-nav" aria-label="Primary">
        <div className="wrap">
          {NAV_ITEMS.map(n => (
            <a key={n.path}
               href={'#' + n.path}
               className={route === n.path ? 'active' : ''}
               onClick={(e)=>{e.preventDefault(); navigate(n.path);}}>
              <span>{n.icon}</span>
              <span>{n.label}</span>
              <span className="nav-hi">· {n.hi}</span>
            </a>
          ))}
        </div>
      </nav>
    </>
  );
}

// -------- Breadcrumb --------
function Breadcrumb({ route }) {
  const item = NAV_ITEMS.find(n => n.path === route) || NAV_ITEMS[0];
  return (
    <div className="breadcrumb">
      <div className="wrap">
        <a href="#/">Home</a>
        {route !== '/' && <><span className="sep">›</span><span style={{color:'var(--ink-2)',fontWeight:500}}>{item.label} · {item.hi}</span></>}
      </div>
    </div>
  );
}

// -------- Footer --------
function GovFooter() {
  return (
    <footer className="gov-footer">
      <div className="wrap">
        <div className="cols">
          <div className="brand-block">
            <h4>KrishiSetu · कृषिसेतु</h4>
            <p style={{margin:0}}>
              A joint initiative of the Ministry of Agriculture &amp; Farmers Welfare, powered by
              AgriStack, Bhashini, PFMS and the India Stack. Enabling transparent, voice-first mandi
              procurement across 22 constitutional languages.
            </p>
            <div className="hstack" style={{marginTop:14, gap:10}}>
              <span className="chip chip-navy" style={{background:'#0f4bb0',color:'#fff',borderColor:'#0f4bb0'}}>Digital India</span>
              <span className="chip chip-navy" style={{background:'#0f4bb0',color:'#fff',borderColor:'#0f4bb0'}}>MeitY Certified</span>
              <span className="chip chip-navy" style={{background:'#0f4bb0',color:'#fff',borderColor:'#0f4bb0'}}>WCAG 2.1 AA</span>
            </div>
          </div>
          <div>
            <h4>Quick Links</h4>
            <a href="#/">Live Mandi Status</a>
            <a href="#/farmer">Book a Slot</a>
            <a href="#/track">Track My Crop</a>
            <a href="#">Grievance Redressal</a>
          </div>
          <div>
            <h4>Integrations</h4>
            <a href="#">AgriStack / UFSI</a>
            <a href="#">Bhashini Language AI</a>
            <a href="#">PFMS · DBT</a>
            <a href="#">e-NAM · MSP Tracker</a>
          </div>
          <div>
            <h4>Support</h4>
            <a href="#">IVR: 1800-180-1551</a>
            <a href="#">SMS: KISAN to 51969</a>
            <a href="#">WhatsApp Bot</a>
            <a href="#">Contact CSC</a>
          </div>
        </div>
        <div className="legal">
          <span>© 2026 Ministry of Agriculture &amp; Farmers Welfare, Government of India. All rights reserved.</span>
          <span>Last updated: Today, 09:14 IST · Version 3.2.1</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { useRoute, GovHeader, Breadcrumb, GovFooter, NAV_ITEMS });
