/* Mandi Officer Console — Live queue + Call Next + Row-lock visualization */

const INITIAL_QUEUE = [
  { token:'A-241', farmer:'Baldev Singh',    farmerHi:'बलदेव सिंह',   crop:'🌾 Wheat',    qtl:32, vehicle:'PB-10-CG-2201', arrived:'09:04', status:'serving',  wait:0 },
  { token:'A-242', farmer:'Harpreet Kaur',   farmerHi:'हरप्रीत कौर',  crop:'🌾 Wheat',    qtl:18, vehicle:'PB-10-AB-8834', arrived:'09:12', status:'next',     wait:6 },
  { token:'A-243', farmer:'Manjit Singh',    farmerHi:'मनजीत सिंह',   crop:'🌻 Mustard',  qtl:12, vehicle:'PB-10-DE-1102', arrived:'09:18', status:'waiting',  wait:14 },
  { token:'A-244', farmer:'Sukhwinder Kaur', farmerHi:'सुखविंदर कौर', crop:'🌾 Wheat',    qtl:28, vehicle:'PB-10-FG-9988', arrived:'09:26', status:'waiting',  wait:22 },
  { token:'A-245', farmer:'Gurdev Singh',    farmerHi:'गुरदेव सिंह',   crop:'🫘 Gram',     qtl:15, vehicle:'PB-10-XY-3344', arrived:'09:34', status:'waiting',  wait:30, flag:'agristack' },
  { token:'A-246', farmer:'Jasbir Singh',    farmerHi:'जसबीर सिंह',   crop:'🌾 Wheat',    qtl:22, vehicle:'PB-10-AB-4567', arrived:'09:42', status:'waiting',  wait:38 },
  { token:'A-247', farmer:'Ramesh Kumar',    farmerHi:'रमेश कुमार',    crop:'🌾 Wheat',    qtl:25, vehicle:'PB-10-AB-4567', arrived:'—',      status:'expected', wait:42 },
];

function RowLockDemo() {
  // Two farmers, one slot. Illustrate PG row-lock resolution.
  const [phase, setPhase] = useState(0); // 0=idle, 1=both send, 2=lock A, 3=A commits, 4=B denied
  useEffect(() => {
    const iv = setInterval(() => setPhase(p => (p + 1) % 6), 2200);
    return () => clearInterval(iv);
  }, []);

  const farmerA = { active: phase >= 1, locked: phase >= 2 && phase < 5, committed: phase >= 3 && phase < 5 };
  const farmerB = { active: phase >= 1, blocked: phase >= 2 && phase < 5, denied: phase >= 4 && phase < 5 };

  return (
    <div className="card">
      <div className="card-header">
        <h3>🔒 Concurrency Safeguard · दोहरी बुकिंग रोकथाम</h3>
        <span className="chip chip-navy">PostgreSQL Row-Lock</span>
      </div>
      <div className="card-body">
        <div style={{fontSize:13, color:'var(--ink-2)', marginBottom:16}}>
          Two farmers try to book the <b>same 10:00 AM slot</b> at exactly the same moment. Watch the database prevent a double-booking.
        </div>

        <div style={{display:'grid', gridTemplateColumns:'1fr auto 1fr', gap:14, alignItems:'stretch'}}>
          {/* Farmer A */}
          <div style={{padding:14, borderRadius:8, border:'2px solid ' + (farmerA.committed?'var(--green)':farmerA.locked?'var(--saffron)':'var(--line)'), background: farmerA.committed?'var(--green-3)':farmerA.locked?'#fef9f0':'#fff', transition:'all .3s'}}>
            <div className="hstack" style={{marginBottom:8}}>
              <span style={{fontSize:22}}>👨‍🌾</span>
              <div>
                <div style={{fontWeight:700, fontSize:14}}>Farmer A</div>
                <div style={{fontSize:11, color:'var(--ink-3)'}}>Baldev Singh · Ludhiana</div>
              </div>
            </div>
            <div style={{fontSize:12, fontFamily:'var(--mono)', color:'var(--ink-2)'}}>
              {phase === 0 && '⋯ idle'}
              {phase === 1 && '→ INSERT slot 10:00'}
              {phase === 2 && '🔒 acquired row-lock'}
              {phase === 3 && '✓ COMMIT · token A-246'}
              {phase === 4 && '✓ Token issued'}
              {phase === 5 && '✓ Session ended'}
            </div>
          </div>

          {/* DB in the middle */}
          <div style={{width:130, textAlign:'center', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:4}}>
            <div style={{
              width:70, height:70, borderRadius:'50%',
              background: phase >= 2 && phase < 5 ? 'linear-gradient(135deg, var(--saffron), #ff7f2a)' : 'var(--navy)',
              color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:30,
              boxShadow:'var(--shadow)',
              transition:'background .3s',
            }}>
              🗄️
            </div>
            <div style={{fontSize:11, fontWeight:700, color:'var(--navy)', textTransform:'uppercase', letterSpacing:.3}}>slots table</div>
            <div style={{fontSize:11, color:'var(--ink-3)', fontFamily:'var(--mono)'}}>row: 10:00-AM</div>
            {phase >= 2 && phase < 5 && <span className="chip chip-amber" style={{fontSize:10}}>🔒 LOCKED</span>}
          </div>

          {/* Farmer B */}
          <div style={{padding:14, borderRadius:8, border:'2px solid ' + (farmerB.denied?'var(--red)':farmerB.blocked?'var(--saffron)':'var(--line)'), background: farmerB.denied?'var(--red-3)':farmerB.blocked?'#fef9f0':'#fff', transition:'all .3s'}}>
            <div className="hstack" style={{marginBottom:8}}>
              <span style={{fontSize:22}}>👩‍🌾</span>
              <div>
                <div style={{fontWeight:700, fontSize:14}}>Farmer B</div>
                <div style={{fontSize:11, color:'var(--ink-3)'}}>Harpreet Kaur · Ludhiana</div>
              </div>
            </div>
            <div style={{fontSize:12, fontFamily:'var(--mono)', color:'var(--ink-2)'}}>
              {phase === 0 && '⋯ idle'}
              {phase === 1 && '→ INSERT slot 10:00'}
              {phase === 2 && '⏸ waiting for lock...'}
              {phase === 3 && '⏸ waiting for lock...'}
              {phase === 4 && <span style={{color:'var(--red)', fontWeight:700}}>✗ 10:00 taken · offered 10:15</span>}
              {phase === 5 && '✓ took 10:15 slot'}
            </div>
          </div>
        </div>

        <div style={{marginTop:14, padding:12, background:'var(--navy-3)', borderRadius:6, fontSize:12, color:'var(--ink-2)', fontFamily:'var(--mono)'}}>
          <b style={{color:'var(--navy)'}}>SQL:</b> SELECT * FROM slots WHERE id=? <b style={{color:'var(--saffron)'}}>FOR UPDATE NOWAIT</b>;
        </div>
      </div>
    </div>
  );
}

function OfficerConsole({ navigate }) {
  const [queue, setQueue] = useState(INITIAL_QUEUE);
  const [advancing, setAdvancing] = useState(false);
  const [alertOpen, setAlertOpen] = useState(false);

  const callNext = () => {
    if (advancing) return;
    setAdvancing(true);
    setTimeout(() => {
      setQueue(q => {
        // Remove the "serving" one, promote "next" -> "serving", next waiting -> "next"
        const newQ = q.filter(f => f.status !== 'serving').map((f, i, arr) => {
          if (i === 0) return { ...f, status: 'serving' };
          if (i === 1) return { ...f, status: 'next' };
          return f;
        });
        return newQ;
      });
      setAdvancing(false);
    }, 700);
  };

  return (
    <div className="page">
      <div className="page-title">
        <div>
          <h2>Mandi Officer Console · मंडी अधिकारी पैनल</h2>
          <div className="hindi">गेट प्रबंधन · कतार नियंत्रण</div>
          <div className="sub">Gate entry verification · Live queue management · Weighbridge orchestration</div>
        </div>
        <div className="hstack" style={{gap:10}}>
          <span className="chip chip-green"><span style={{width:6,height:6,borderRadius:'50%',background:'var(--green)',animation:'pulse 2s infinite'}}/> On duty · Jasbir Singh</span>
          <button className="btn btn-outline">📊 End of shift</button>
        </div>
      </div>

      {/* Officer top stats */}
      <div className="grid grid-4" style={{marginBottom:20}}>
        <div className="kpi"><div className="label">Farmers served today</div><div className="value">64</div><div className="hi">आज सेवित</div></div>
        <div className="kpi k-green"><div className="label">Quintals accepted</div><div className="value tabular">1,842</div><div className="hi">क्विंटल स्वीकृत</div></div>
        <div className="kpi k-saffron"><div className="label">Avg service time</div><div className="value">5.8 <span style={{fontSize:14}}>min</span></div><div className="hi">प्रति किसान</div></div>
        <div className="kpi k-red"><div className="label">Rejected consignments</div><div className="value">3</div><div className="hi">अस्वीकृत</div></div>
      </div>

      <div className="grid" style={{gridTemplateColumns:'2fr 1fr', gap:20}}>

        {/* LEFT · Queue */}
        <div className="card">
          <div className="card-header">
            <h3>🚦 Live Queue · वर्तमान कतार</h3>
            <div className="hstack" style={{gap:8}}>
              <span className="chip chip-navy mono">Gate 2 · Block C</span>
              <button
                onClick={callNext}
                disabled={advancing}
                className="btn btn-saffron"
                style={{padding:'8px 18px', fontSize:14}}>
                {advancing ? '⏳ Advancing...' : '▶ Call Next · अगला बुलाएँ'}
              </button>
            </div>
          </div>
          <div className="card-body" style={{padding:0}}>
            <table className="gov-table">
              <thead>
                <tr>
                  <th>Token</th>
                  <th>Farmer</th>
                  <th>Crop</th>
                  <th>Qtl</th>
                  <th>Vehicle</th>
                  <th>Arrived</th>
                  <th>Wait</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {queue.map(f => (
                  <tr key={f.token} style={{
                    background: f.status==='serving' ? 'var(--green-3)' :
                                f.status==='next' ? '#fef9f0' :
                                f.flag ? 'var(--red-3)' : 'transparent',
                    transition:'background .4s',
                    animation: advancing && f.status==='serving' ? 'fadeOut .7s' : 'none',
                  }}>
                    <td style={{fontFamily:'var(--mono)', fontWeight:700, color:'var(--navy)'}}>{f.token}</td>
                    <td>
                      <div style={{fontWeight:600}}>{f.farmer}</div>
                      <div style={{fontSize:11, color:'var(--ink-3)'}}>{f.farmerHi}</div>
                    </td>
                    <td>{f.crop}</td>
                    <td className="tabular" style={{fontWeight:600}}>{f.qtl}</td>
                    <td className="mono" style={{fontSize:12}}>{f.vehicle}</td>
                    <td className="mono" style={{fontSize:12}}>{f.arrived}</td>
                    <td className="tabular" style={{fontSize:12, color: f.wait > 20 ? 'var(--red)':'var(--ink-2)'}}>{f.wait} min</td>
                    <td>
                      {f.status === 'serving'  && <span className="chip chip-green">🔴 Serving</span>}
                      {f.status === 'next'     && <span className="chip chip-amber">⏭ Next</span>}
                      {f.status === 'waiting'  && <span className="chip chip-gray">Waiting</span>}
                      {f.status === 'expected' && <span className="chip chip-navy">Expected</span>}
                    </td>
                    <td>
                      {f.flag === 'agristack' && (
                        <button onClick={()=>setAlertOpen(true)} style={{background:'var(--red)',color:'#fff',border:'none',padding:'4px 10px',borderRadius:4,fontSize:11,fontWeight:700,cursor:'pointer'}}>
                          ⚠ FLAG
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* RIGHT · Now serving + Row-lock */}
        <div className="vstack" style={{gap:16}}>
          <div className="card">
            <div className="card-header">
              <h3>👤 Now Serving · अभी सेवा में</h3>
            </div>
            <div className="card-body">
              {(() => {
                const s = queue.find(f => f.status === 'serving');
                if (!s) return <div style={{color:'var(--ink-3)'}}>None</div>;
                return (
                  <>
                    <div style={{fontSize:12, color:'var(--ink-3)', textTransform:'uppercase', letterSpacing:.4, fontWeight:700}}>Token</div>
                    <div style={{fontSize:48, fontWeight:800, color:'var(--navy)', fontFamily:'var(--mono)', letterSpacing:-2, lineHeight:1}}>{s.token}</div>
                    <div style={{fontSize:18, fontWeight:600, marginTop:8}}>{s.farmer}</div>
                    <div style={{fontSize:14, color:'var(--ink-3)'}}>{s.farmerHi}</div>
                    <div style={{marginTop:14, display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, fontSize:13}}>
                      <div><div className="small muted">Crop</div><div style={{fontWeight:600}}>{s.crop}</div></div>
                      <div><div className="small muted">Weight</div><div style={{fontWeight:600}}>{s.qtl} qtl</div></div>
                      <div><div className="small muted">Vehicle</div><div className="mono" style={{fontSize:12,fontWeight:600}}>{s.vehicle}</div></div>
                      <div><div className="small muted">Arrived</div><div className="mono" style={{fontSize:12,fontWeight:600}}>{s.arrived}</div></div>
                    </div>
                    <div className="hstack" style={{gap:8, marginTop:16}}>
                      <button className="btn btn-green" style={{flex:1}}>✓ Accept</button>
                      <button className="btn btn-danger" style={{flex:1}}>✗ Reject</button>
                    </div>
                  </>
                );
              })()}
            </div>
          </div>

          <RowLockDemo />
        </div>
      </div>

      {/* AgriStack fraud alert modal */}
      {alertOpen && (
        <div style={{position:'fixed', inset:0, background:'rgba(15,23,42,.6)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:100, padding:20}} onClick={()=>setAlertOpen(false)}>
          <div className="card" style={{maxWidth:520, width:'100%'}} onClick={e=>e.stopPropagation()}>
            <div className="card-header" style={{background:'var(--red)', color:'#fff', borderBottom:'none'}}>
              <h3 style={{color:'#fff'}}>⚠️ AgriStack Anti-Hoarding Alert</h3>
            </div>
            <div className="card-body">
              <div style={{padding:14, background:'var(--red-3)', border:'1px solid #f0b8ba', borderRadius:6, marginBottom:14}}>
                <div style={{fontSize:14, fontWeight:700, color:'var(--red)'}}>Suspected middleman hoarding</div>
                <div style={{fontSize:13, color:'var(--ink-2)', marginTop:4}}>Token A-245 · Gurdev Singh</div>
              </div>
              <div style={{fontSize:13, lineHeight:1.7}}>
                <div><b>Land record:</b> 0.8 ha (Khasra 118/4)</div>
                <div><b>Declared weight:</b> 15 quintals of Gram</div>
                <div><b>Expected yield at 0.8 ha:</b> ~10 quintals max</div>
                <div style={{marginTop:8, padding:10, background:'var(--amber-3)', borderRadius:4, fontSize:12}}>
                  🚨 <b>AgriStack cross-check:</b> This Aadhaar has booked <b>4 tokens</b> across 3 mandis this week — cumulative 62 quintals of gram against 0.8 ha holding. Pattern flagged as consolidator/middleman.
                </div>
              </div>
              <div className="hstack" style={{marginTop:16, gap:10}}>
                <button className="btn btn-outline" style={{flex:1}} onClick={()=>setAlertOpen(false)}>Investigate later</button>
                <button className="btn btn-danger" style={{flex:1}}>🛡️ Reject & Report</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes fadeOut { 0%{opacity:1} 100%{opacity:.2} }
      `}</style>
    </div>
  );
}

Object.assign(window, { OfficerConsole });
