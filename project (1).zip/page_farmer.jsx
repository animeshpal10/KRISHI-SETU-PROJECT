/* Farmer Portal — Voice-first booking with auto-filling wizard */

const CROPS = [
  { id:'wheat',   icon:'🌾', name:'Wheat',   hi:'गेहूं',  msp:'₹2,425/qtl' },
  { id:'paddy',   icon:'🌱', name:'Paddy',   hi:'धान',    msp:'₹2,300/qtl' },
  { id:'mustard', icon:'🌻', name:'Mustard', hi:'सरसों',  msp:'₹5,950/qtl' },
  { id:'gram',    icon:'🫘', name:'Gram',    hi:'चना',    msp:'₹5,650/qtl' },
];

const VEHICLES = [
  { id:'tractor', icon:'🚜', name:'Tractor + Trolley', hi:'ट्रैक्टर-ट्रॉली', cap:'up to 40 qtl' },
  { id:'pickup',  icon:'🛻', name:'Pickup Van',        hi:'पिकअप वैन',      cap:'up to 15 qtl' },
  { id:'truck',   icon:'🚚', name:'Mini Truck',        hi:'मिनी ट्रक',        cap:'up to 80 qtl' },
  { id:'cart',    icon:'🐂', name:'Bullock Cart',      hi:'बैलगाड़ी',        cap:'up to 8 qtl' },
];

// Scripted "farmer speech" the mic simulates (Hindi + Bhashini English translation)
const VOICE_SCRIPT = [
  {
    t: 800,  hi:'नमस्ते... मुझे मंडी में स्लॉट बुक करना है।',
    en:'Hello... I want to book a mandi slot.',
    fills: null
  },
  {
    t: 3800, hi:'मेरे पास पच्चीस क्विंटल गेहूं है।',
    en:'I have twenty-five quintals of wheat.',
    fills: { crop:'wheat', weight:25 }
  },
  {
    t: 7200, hi:'कल सुबह दस बजे लेकर आऊंगा।',
    en:'I will bring it tomorrow at 10 AM.',
    fills: { date:'tomorrow', time:'10:00 AM' }
  },
  {
    t: 10500, hi:'ट्रैक्टर-ट्रॉली से आऊंगा, नंबर पीबी-दस-एबी-चार-पांच-छह-सात।',
    en:'I will come by tractor-trolley, number PB-10-AB-4567.',
    fills: { vehicle:'tractor', vehicleNo:'PB-10-AB-4567' }
  },
  {
    t: 14500, hi:'लुधियाना खन्ना मंडी में बुक करो।',
    en:'Book it at Ludhiana Khanna Mandi.',
    fills: { mandi:'Khanna Mandi, Ludhiana' }
  },
];

function VoiceMic({ listening, onToggle, level }) {
  return (
    <div style={{position:'relative', width:200, height:200, margin:'0 auto'}}>
      {listening && [1,2,3].map(i=>(
        <div key={i} style={{
          position:'absolute', inset:0, borderRadius:'50%',
          border:'2px solid var(--saffron)', opacity: 0.6 / i,
          animation:`ripple 2s ${i*0.4}s ease-out infinite`
        }}/>
      ))}
      <button
        onClick={onToggle}
        aria-label={listening ? 'Stop listening' : 'Start voice booking'}
        style={{
          width:200, height:200, borderRadius:'50%',
          background: listening
            ? 'radial-gradient(circle at 50% 40%, #ff7f2a, #c1272d)'
            : 'radial-gradient(circle at 50% 40%, var(--navy-2), var(--navy))',
          border: '6px solid #fff',
          boxShadow: '0 12px 40px rgba(11,61,145,.3), inset 0 -8px 16px rgba(0,0,0,.15)',
          color:'#fff', fontSize:80, cursor:'pointer',
          transition:'transform .15s',
          transform: listening ? `scale(${1 + level*0.05})` : 'scale(1)',
          position:'relative', zIndex:2,
        }}>
        🎙️
      </button>
      <style>{`
        @keyframes ripple {
          0% { transform: scale(1); opacity: 0.6; }
          100% { transform: scale(1.6); opacity: 0; }
        }
      `}</style>
    </div>
  );
}

function TranscriptBubble({ hi, en, isFinal }) {
  return (
    <div style={{
      background: isFinal ? '#fff' : '#fef9f0',
      border: '1.5px solid ' + (isFinal ? 'var(--green)' : 'var(--saffron)'),
      borderRadius: 12, padding:'12px 16px', marginBottom:10,
      boxShadow:'var(--shadow-sm)',
      animation:'slideIn .3s ease-out',
    }}>
      <div style={{fontSize:11, fontWeight:700, color:'var(--saffron)', textTransform:'uppercase', letterSpacing:.4, marginBottom:4}}>
        🎙️ Farmer said · किसान ने कहा {isFinal && <span style={{color:'var(--green)', marginLeft:8}}>✓ processed</span>}
      </div>
      <div style={{fontSize:17, color:'var(--ink)', fontWeight:500}}>{hi}</div>
      <div style={{fontSize:13, color:'var(--ink-3)', marginTop:4, fontStyle:'italic'}}>
        <span style={{background:'var(--navy-3)', color:'var(--navy)', padding:'1px 6px', borderRadius:3, fontWeight:600, fontSize:10, marginRight:6}}>BHASHINI NMT</span>
        {en}
      </div>
    </div>
  );
}

function FarmerPortal({ navigate }) {
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState([]); // {hi, en, isFinal}
  const [level, setLevel] = useState(0);
  const [form, setForm] = useState({ crop:null, weight:'', date:'', time:'', vehicle:null, vehicleNo:'', mandi:'' });
  const [step, setStep] = useState(1); // completion progress
  const timersRef = useRef([]);

  // Simulate audio waveform level
  useEffect(() => {
    if (!listening) { setLevel(0); return; }
    const iv = setInterval(() => setLevel(Math.random()), 120);
    return () => clearInterval(iv);
  }, [listening]);

  const startListening = () => {
    // reset
    setTranscript([]);
    setForm({ crop:null, weight:'', date:'', time:'', vehicle:null, vehicleNo:'', mandi:'' });
    setStep(1);
    setListening(true);

    VOICE_SCRIPT.forEach((chunk, idx) => {
      // Show partial (typing) then finalize
      const partialT = setTimeout(() => {
        setTranscript(prev => [...prev, { hi: chunk.hi, en: chunk.en, isFinal: false }]);
      }, chunk.t);
      const finalT = setTimeout(() => {
        setTranscript(prev => prev.map((b,i) => i === prev.length-1 ? {...b, isFinal:true} : b));
        if (chunk.fills) {
          setForm(f => ({...f, ...chunk.fills}));
          setStep(s => Math.max(s, idx+2));
        }
      }, chunk.t + 1200);
      timersRef.current.push(partialT, finalT);
    });

    // finish
    const doneT = setTimeout(() => setListening(false), VOICE_SCRIPT[VOICE_SCRIPT.length-1].t + 2500);
    timersRef.current.push(doneT);
  };

  const stopListening = () => {
    timersRef.current.forEach(clearTimeout);
    timersRef.current = [];
    setListening(false);
  };

  useEffect(() => () => timersRef.current.forEach(clearTimeout), []);

  const canSubmit = form.crop && form.weight && form.date && form.time && form.vehicle && form.vehicleNo && form.mandi;

  const submitBooking = () => {
    // Persist token payload for /token & /track pages
    const token = {
      id: 'KS-' + Math.random().toString(36).slice(2,8).toUpperCase(),
      tokenNo: 'A-' + (100 + Math.floor(Math.random()*899)),
      farmer: 'Ramesh Kumar',
      farmerHi: 'रमेश कुमार',
      aadhaar: 'XXXX-XXXX-4782',
      village: 'Rauni, Ludhiana',
      ...form,
      cropObj: CROPS.find(c=>c.id===form.crop),
      vehicleObj: VEHICLES.find(v=>v.id===form.vehicle),
      queuePosition: 7,
      etaMin: 42,
      issuedAt: new Date().toISOString(),
    };
    localStorage.setItem('ks_token', JSON.stringify(token));
    navigate('/token');
  };

  return (
    <div className="page">
      <div className="page-title">
        <div>
          <h2>Book Your Mandi Slot · मंडी स्लॉट बुक करें</h2>
          <div className="hindi">बस बोलिए — हम आपकी बुकिंग कर देंगे</div>
          <div className="sub">Just speak in your language — we'll fill the form for you. Free, secure, Aadhaar-verified.</div>
        </div>
        <div className="hstack" style={{gap:10}}>
          <button className="btn btn-outline" onClick={()=>document.getElementById('ivr-modal').showModal()}>
            📞 No smartphone? Use missed-call
          </button>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:'1fr 1.15fr', gap:20}}>

        {/* LEFT · Voice mic + transcript */}
        <div className="card" style={{background:'linear-gradient(180deg, #f4f7fd 0%, #eef2fa 100%)'}}>
          <div className="card-header" style={{background:'transparent'}}>
            <h3>🎙️ Voice Booking · आवाज़ से बुकिंग</h3>
            <span className="chip chip-navy">Bhashini AI · 22 भाषाएँ</span>
          </div>
          <div className="card-body">

            <div style={{textAlign:'center', padding:'20px 0 24px'}}>
              <VoiceMic listening={listening} level={level} onToggle={listening ? stopListening : startListening} />
              <div style={{marginTop:20, fontSize:20, fontWeight:600, color:'var(--navy)'}}>
                {listening ? '🔴 Listening... सुन रहा हूँ' : 'Tap the mic to start · बोलने के लिए दबाइए'}
              </div>
              <div style={{fontSize:14, color:'var(--ink-3)', marginTop:6}}>
                {listening ? 'Speak in Hindi, Punjabi, Tamil, or any Indian language' : 'हिंदी, पंजाबी, तमिल — किसी भी भाषा में बोलें'}
              </div>

              {!listening && transcript.length === 0 && (
                <div className="hstack" style={{justifyContent:'center', gap:8, marginTop:20, flexWrap:'wrap'}}>
                  {['हिंदी','ਪੰਜਾਬੀ','தமிழ்','తెలుగు','मराठी','বাংলা','ગુજરાતી','ಕನ್ನಡ'].map(l=>(
                    <span key={l} className="chip chip-gray" style={{fontSize:13}}>{l}</span>
                  ))}
                  <span className="chip chip-gray" style={{fontSize:13}}>+14 more</span>
                </div>
              )}
            </div>

            {/* Transcript */}
            {transcript.length > 0 && (
              <div style={{maxHeight:280, overflowY:'auto', padding:'8px 4px', borderTop:'1px dashed var(--line)'}}>
                <div style={{fontSize:11, fontWeight:700, color:'var(--ink-3)', textTransform:'uppercase', letterSpacing:.4, marginBottom:8, marginTop:8}}>
                  Live Transcript · वास्तविक-समय प्रतिलेखन
                </div>
                {transcript.map((b,i)=>(<TranscriptBubble key={i} {...b} />))}
              </div>
            )}
          </div>
        </div>

        {/* RIGHT · Auto-filling wizard */}
        <div className="card">
          <div className="card-header">
            <h3>📋 Booking Form · बुकिंग फ़ॉर्म</h3>
            <span className="small muted">Step {step} of 5 · चरण {step}/5</span>
          </div>
          <div className="card-body">

            {/* Progress bar */}
            <div style={{display:'flex', gap:4, marginBottom:20}}>
              {[1,2,3,4,5].map(n=>(
                <div key={n} style={{flex:1, height:6, borderRadius:3, background: step>=n ? 'var(--green)' : 'var(--line)', transition:'background .4s'}}/>
              ))}
            </div>

            {/* Farmer identity (pre-filled via AgriStack) */}
            <div style={{background:'var(--green-3)', border:'1px solid #b8dbb2', borderRadius:6, padding:'10px 14px', marginBottom:18, display:'flex', gap:12, alignItems:'center'}}>
              <div style={{width:36, height:36, borderRadius:'50%', background:'var(--green)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, flexShrink:0}}>✓</div>
              <div style={{flex:1}}>
                <div style={{fontSize:13, fontWeight:700, color:'var(--green)'}}>Aadhaar & Land Verified · आधार व भूमि सत्यापित</div>
                <div style={{fontSize:13, color:'var(--ink-2)'}}>Ramesh Kumar · रमेश कुमार · Rauni, Ludhiana · Khasra: 234/12 (2.4 ha)</div>
              </div>
              <span className="chip chip-navy" style={{flexShrink:0}}>AgriStack</span>
            </div>

            {/* Crop */}
            <div style={{marginBottom:16}}>
              <label className="f-label">1. Which crop? <span className="hi">कौन-सी फसल?</span></label>
              <div className="chip-picker">
                {CROPS.map(c=>(
                  <button key={c.id} type="button"
                    className={'chip-btn' + (form.crop===c.id?' selected':'')}
                    onClick={()=>setForm(f=>({...f, crop:c.id}))}>
                    <span className="icon">{c.icon}</span>
                    <span>{c.name}</span>
                    <span className="hi">{c.hi}</span>
                  </button>
                ))}
              </div>
              {form.crop && <div className="small" style={{color:'var(--green)', marginTop:8, fontWeight:600}}>✓ MSP: {CROPS.find(c=>c.id===form.crop).msp}</div>}
            </div>

            {/* Weight */}
            <div style={{marginBottom:16}}>
              <label className="f-label">2. Weight in quintals? <span className="hi">कितने क्विंटल?</span></label>
              <input
                className={'f-input' + (form.weight?' filled':'')}
                type="number" placeholder="e.g. 25" value={form.weight}
                onChange={e=>setForm(f=>({...f, weight:e.target.value}))}
                style={{fontSize:20, fontWeight:600, textAlign:'center'}}
              />
            </div>

            {/* Date + Time */}
            <div className="grid grid-2" style={{marginBottom:16}}>
              <div>
                <label className="f-label">3. Date · तारीख</label>
                <select className={'f-select' + (form.date?' filled':'')} value={form.date} onChange={e=>setForm(f=>({...f, date:e.target.value}))}>
                  <option value="">Choose...</option>
                  <option value="today">Today · आज</option>
                  <option value="tomorrow">Tomorrow · कल</option>
                  <option value="day-after">Day after · परसों</option>
                </select>
              </div>
              <div>
                <label className="f-label">Time · समय</label>
                <select className={'f-select' + (form.time?' filled':'')} value={form.time} onChange={e=>setForm(f=>({...f, time:e.target.value}))}>
                  <option value="">Choose...</option>
                  <option value="08:00 AM">08:00 AM · सुबह ८</option>
                  <option value="10:00 AM">10:00 AM · सुबह १०</option>
                  <option value="12:00 PM">12:00 PM · दोपहर १२</option>
                  <option value="02:00 PM">02:00 PM · दोपहर २</option>
                </select>
              </div>
            </div>

            {/* Vehicle */}
            <div style={{marginBottom:16}}>
              <label className="f-label">4. Vehicle · वाहन</label>
              <div className="chip-picker">
                {VEHICLES.map(v=>(
                  <button key={v.id} type="button"
                    className={'chip-btn' + (form.vehicle===v.id?' selected':'')}
                    onClick={()=>setForm(f=>({...f, vehicle:v.id}))}>
                    <span className="icon">{v.icon}</span>
                    <span>{v.name}</span>
                    <span className="hi">{v.hi}</span>
                  </button>
                ))}
              </div>
              <input
                className={'f-input' + (form.vehicleNo?' filled':'')}
                placeholder="Vehicle number · वाहन नंबर (e.g. PB-10-AB-4567)"
                style={{marginTop:10, fontFamily:'var(--mono)', fontSize:16, textTransform:'uppercase'}}
                value={form.vehicleNo}
                onChange={e=>setForm(f=>({...f, vehicleNo:e.target.value.toUpperCase()}))}
              />
            </div>

            {/* Mandi */}
            <div style={{marginBottom:20}}>
              <label className="f-label">5. Mandi · मंडी</label>
              <select className={'f-select' + (form.mandi?' filled':'')} value={form.mandi} onChange={e=>setForm(f=>({...f, mandi:e.target.value}))}>
                <option value="">Choose nearest mandi...</option>
                <option value="Khanna Mandi, Ludhiana">Khanna Mandi, Ludhiana (8 km) · 🟢 Open</option>
                <option value="Samrala Mandi, Ludhiana">Samrala Mandi, Ludhiana (14 km) · 🟡 Busy</option>
                <option value="Doraha Mandi, Ludhiana">Doraha Mandi, Ludhiana (22 km) · 🟢 Open</option>
              </select>
            </div>

            <button
              onClick={submitBooking}
              disabled={!canSubmit}
              className="btn btn-green btn-xl"
              style={{width:'100%', opacity: canSubmit?1:0.5, cursor: canSubmit?'pointer':'not-allowed'}}>
              ✓ Confirm & Generate Token · टोकन जनरेट करें
            </button>
            <div className="small muted" style={{textAlign:'center', marginTop:10}}>
              🔒 Slot secured via PostgreSQL row-lock — cannot be double-booked
            </div>
          </div>
        </div>
      </div>

      {/* IVR/SMS modal */}
      <IvrModal />

      <style>{`
        @keyframes slideIn { from{opacity:0; transform:translateY(-6px)} to{opacity:1; transform:translateY(0)} }
      `}</style>
    </div>
  );
}

function IvrModal() {
  return (
    <dialog id="ivr-modal" style={{border:'none', padding:0, borderRadius:12, boxShadow:'var(--shadow-lg)', maxWidth:820, width:'92vw'}}>
      <div style={{background:'var(--navy)', color:'#fff', padding:'16px 20px', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <div>
          <div style={{fontSize:18, fontWeight:700}}>📞 Feature-Phone Booking · फीचर फ़ोन बुकिंग</div>
          <div style={{fontSize:13, opacity:.8}}>No smartphone, no internet — no problem</div>
        </div>
        <button onClick={()=>document.getElementById('ivr-modal').close()}
          style={{background:'transparent', border:'1px solid rgba(255,255,255,.3)', color:'#fff', width:32, height:32, borderRadius:16, cursor:'pointer', fontSize:18}}>×</button>
      </div>
      <div style={{padding:24, background:'#fff'}}>
        <div className="grid grid-2" style={{gap:24}}>
          {/* Feature-phone visual */}
          <div style={{background:'#f4f6fb', borderRadius:12, padding:20, display:'flex', flexDirection:'column', alignItems:'center'}}>
            <div style={{width:180, background:'#222', borderRadius:20, padding:'20px 14px', color:'#c9f0a0', fontFamily:'var(--mono)', fontSize:11, lineHeight:1.5, textAlign:'left', boxShadow:'inset 0 2px 8px rgba(0,0,0,.4)'}}>
              <div style={{background:'#0a3a0a', padding:'6px 8px', borderRadius:3, marginBottom:6}}>
                <div style={{fontSize:9, opacity:.7}}>KrishiSetu IVR</div>
                <div>1800-180-1551</div>
              </div>
              <div>&gt; नमस्ते! भाषा चुनें:</div>
              <div>&nbsp;&nbsp;1 हिंदी</div>
              <div>&nbsp;&nbsp;2 ਪੰਜਾਬੀ</div>
              <div>&nbsp;&nbsp;3 English</div>
              <div style={{marginTop:4, opacity:.6}}>&gt; _ press 1</div>
              <div style={{marginTop:6}}>&gt; फसल बताइए...</div>
              <div>&nbsp;&nbsp;<span style={{color:'#ff9933'}}>"गेहूं"</span></div>
              <div style={{marginTop:4, opacity:.7}}>✓ 25 qtl गेहूं</div>
              <div>✓ Token: A-247</div>
            </div>
            <div style={{marginTop:14, fontSize:13, color:'var(--ink-3)', textAlign:'center'}}>
              Nokia 105 · Any feature phone · कोई भी बुनियादी फ़ोन
            </div>
          </div>
          {/* Steps */}
          <div>
            <div style={{fontSize:14, fontWeight:700, color:'var(--navy)', marginBottom:14, textTransform:'uppercase', letterSpacing:.3}}>How it works · कैसे काम करता है</div>
            {[
              {n:1, t:'Give a missed call', hi:'मिस्ड कॉल दीजिए', d:'1800-180-1551 — we call back in 30 seconds'},
              {n:2, t:'Choose your language', hi:'भाषा चुनें', d:'Press 1-9 for any of 22 official languages'},
              {n:3, t:'Speak your details', hi:'अपनी बात बताएँ', d:'"25 quintal wheat, tomorrow morning" — Bhashini understands'},
              {n:4, t:'Receive SMS token', hi:'SMS पर टोकन', d:'Token number + QR + gate arrives in 60 seconds'},
              {n:5, t:'Show SMS at gate', hi:'गेट पर SMS दिखाएँ', d:'Officer scans code — you enter mandi'},
            ].map(s=>(
              <div key={s.n} style={{display:'flex', gap:12, marginBottom:12, alignItems:'flex-start'}}>
                <div style={{width:28, height:28, borderRadius:'50%', background:'var(--saffron)', color:'#3a2100', fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center', fontSize:13, flexShrink:0}}>{s.n}</div>
                <div>
                  <div style={{fontSize:14, fontWeight:600, color:'var(--ink)'}}>{s.t} · <span style={{color:'var(--ink-3)', fontWeight:500}}>{s.hi}</span></div>
                  <div style={{fontSize:13, color:'var(--ink-3)'}}>{s.d}</div>
                </div>
              </div>
            ))}
            <div style={{marginTop:14, padding:12, background:'var(--amber-3)', border:'1px solid #f0d288', borderRadius:6, fontSize:13}}>
              <b>📱 SMS Alternative:</b> Text <span style={{fontFamily:'var(--mono)', background:'#fff', padding:'1px 6px', borderRadius:3}}>KISAN</span> to <b>51969</b>
            </div>
          </div>
        </div>
      </div>
    </dialog>
  );
}

Object.assign(window, { FarmerPortal });
