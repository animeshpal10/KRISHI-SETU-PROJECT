/* KrishiSetu — shared nav, i18n toggle, mock data */
(function () {
  const NAV = [
    { href: "index.html", en: "Home", hi: "मुख्य" },
    { href: "farmer.html", en: "Farmer Portal", hi: "किसान पोर्टल" },
    { href: "token.html", en: "My Token", hi: "मेरा टोकन" },
    { href: "track.html", en: "Track Sale", hi: "बिक्री देखें" },
    { href: "officer.html", en: "Officer", hi: "अधिकारी" },
    { href: "admin.html", en: "State Admin", hi: "राज्य प्रशासन" },
    { href: "ivr-sms.html", en: "IVR / SMS", hi: "फोन सेवा" },
    { href: "concurrency.html", en: "Row-Lock", hi: "स्लॉट सुरक्षा" },
  ];

  function currentFile() {
    const p = location.pathname.split("/").pop();
    return p && p.length ? p : "index.html";
  }

  function chrome() {
    const cur = currentFile();
    const linksHTML = NAV.map(n =>
      `<a href="${n.href}" class="${n.href === cur ? "active" : ""}" title="${n.en}">${n.en}</a>`
    ).join("");

    return `
    <div class="tricolor-strip" aria-hidden="true"></div>
    <div class="gov-ribbon">
      <div class="wrap">
        <div class="l">
          <span>🇮🇳 भारत सरकार | Government of India</span>
          <span class="dot"></span>
          <span>Ministry of Agriculture &amp; Farmers Welfare</span>
          <span class="dot"></span>
          <span>कृषि एवं किसान कल्याण मंत्रालय</span>
        </div>
        <div class="r">
          <a href="#skip">Skip to content</a>
          <span class="dot"></span>
          <a href="#a">A-</a><a href="#a">A</a><a href="#a">A+</a>
          <span class="dot"></span>
          <a href="#hc">High Contrast</a>
          <span class="dot"></span>
          <a href="#screen">Screen Reader</a>
        </div>
      </div>
    </div>
    <nav class="nav" aria-label="Primary">
      <div class="wrap">
        <a class="brand" href="index.html">
          <div class="emblem" aria-hidden="true">
            <svg viewBox="0 0 40 40" width="28" height="28"><g fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="20" cy="20" r="9"/><g><line x1="20" y1="7" x2="20" y2="33"/><line x1="7" y1="20" x2="33" y2="20"/><line x1="10.8" y1="10.8" x2="29.2" y2="29.2"/><line x1="29.2" y1="10.8" x2="10.8" y2="29.2"/><line x1="20" y1="7.5" x2="24" y2="12"/><line x1="20" y1="7.5" x2="16" y2="12"/></g></g></svg>
          </div>
          <div class="b-txt">
            <div class="b-hi">कृषि सेतु — स्मार्ट मंडी</div>
            <div class="b-en">KrishiSetu</div>
            <div class="b-sub">Smart Mandi · SIH 2026</div>
          </div>
        </a>
        <div class="nav-links" role="menubar">
          ${linksHTML}
          <div class="lang-toggle" role="group" aria-label="Language">
            <button data-lang="hi" class="on">हिं</button>
            <button data-lang="en">EN</button>
            <button data-lang="pa">ਪੰ</button>
          </div>
          <a href="ivr-sms.html" class="helpline-pill" title="Toll-free Kisan Helpline">📞 1800-180-KISAN</a>
        </div>
      </div>
    </nav>`;
  }

  function footer() {
    return `
    <footer class="footer">
      <div class="wrap">
        <div>
          <h4>KrishiSetu — कृषि सेतु</h4>
          <p style="font-size:13px; line-height:1.6; margin:0 0 12px;">A trustless digital queue &amp; transparent procurement platform for Indian mandis. Voice-first, feature-phone-ready, Aadhaar-verified.</p>
          <p style="font-size:11px; color:#8CA0BE;">Powered by Bhashini · AgriStack · PFMS · UPI · DigiLocker</p>
        </div>
        <div>
          <h4>For Farmers</h4>
          <a href="farmer.html">Book a slot</a>
          <a href="track.html">Track my sale</a>
          <a href="token.html">View token</a>
          <a href="ivr-sms.html">Call 1800-180-KISAN</a>
        </div>
        <div>
          <h4>For Officers</h4>
          <a href="officer.html">Gate console</a>
          <a href="admin.html">State dashboard</a>
          <a href="concurrency.html">Slot integrity</a>
        </div>
        <div>
          <h4>Compliance</h4>
          <a href="#">RTI · सूचना का अधिकार</a>
          <a href="#">Data Privacy (DPDP Act)</a>
          <a href="#">Accessibility (WCAG 2.1 AA)</a>
          <a href="#">Grievance Redressal</a>
        </div>
      </div>
      <div class="fine">
        <div>© 2026 Government of India · Content owned &amp; managed by Ministry of Agriculture &amp; Farmers Welfare · Last reviewed: 10 Sept 2026</div>
        <div>Best viewed in Chrome 90+, Firefox 88+ · Bandwidth-optimized for 2G/3G rural networks</div>
      </div>
    </footer>`;
  }

  function mountChrome() {
    const host = document.getElementById("gov-chrome");
    if (host) host.innerHTML = chrome();
    const foot = document.getElementById("gov-footer");
    if (foot) foot.innerHTML = footer();

    // language toggle behavior — cosmetic (bilingual UI stays)
    document.querySelectorAll(".lang-toggle button").forEach(b => {
      b.addEventListener("click", () => {
        document.querySelectorAll(".lang-toggle button").forEach(x => x.classList.remove("on"));
        b.classList.add("on");
      });
    });
  }

  window.KRISHI = {
    mountChrome,
    // Mock data used across pages
    mandis: [
      { id: "KRN01", name: "Karnal APMC",       hi: "करनाल कृषि उपज मंडी",  district: "Karnal",       state: "Haryana", capacity: 240, current: 187, wait: 42, status: "busy", crops: ["Paddy", "Wheat"] },
      { id: "KTL02", name: "Kaithal Grain Mkt", hi: "कैथल अनाज मंडी",       district: "Kaithal",      state: "Haryana", capacity: 180, current: 96,  wait: 18, status: "open", crops: ["Paddy", "Mustard"] },
      { id: "KKR03", name: "Kurukshetra Mandi", hi: "कुरुक्षेत्र मंडी",       district: "Kurukshetra",  state: "Haryana", capacity: 200, current: 200, wait: 65, status: "full", crops: ["Paddy"] },
      { id: "PPT04", name: "Panipat APMC",      hi: "पानीपत मंडी",           district: "Panipat",      state: "Haryana", capacity: 160, current: 74,  wait: 12, status: "open", crops: ["Paddy", "Gram"] },
      { id: "SNP05", name: "Sonipat Grain Yard",hi: "सोनीपत अनाज मंडी",      district: "Sonipat",      state: "Haryana", capacity: 210, current: 158, wait: 34, status: "busy", crops: ["Wheat", "Mustard"] },
      { id: "HSR06", name: "Hisar Mandi",       hi: "हिसार मंडी",            district: "Hisar",        state: "Haryana", capacity: 260, current: 122, wait: 20, status: "open", crops: ["Gram", "Mustard"] },
      { id: "AMB07", name: "Ambala Cantt Mandi",hi: "अंबाला मंडी",           district: "Ambala",       state: "Haryana", capacity: 140, current: 138, wait: 55, status: "full", crops: ["Paddy"] },
      { id: "RTK08", name: "Rohtak APMC",       hi: "रोहतक मंडी",            district: "Rohtak",       state: "Haryana", capacity: 190, current: 101, wait: 22, status: "open", crops: ["Wheat", "Gram"] },
      { id: "JND09", name: "Jind Grain Market", hi: "जींद मंडी",             district: "Jind",         state: "Haryana", capacity: 170, current: 148, wait: 38, status: "busy", crops: ["Paddy"] },
      { id: "SRS10", name: "Sirsa Mandi",       hi: "सिरसा मंडी",            district: "Sirsa",        state: "Haryana", capacity: 220, current: 89,  wait: 15, status: "open", crops: ["Mustard", "Gram"] },
      { id: "FTB11", name: "Fatehabad APMC",    hi: "फतेहाबाद मंडी",         district: "Fatehabad",    state: "Haryana", capacity: 150, current: 132, wait: 44, status: "busy", crops: ["Paddy", "Wheat"] },
      { id: "YMN12", name: "Yamunanagar Mandi", hi: "यमुनानगर मंडी",          district: "Yamunanagar",  state: "Haryana", capacity: 130, current: 60,  wait: 11, status: "open", crops: ["Paddy"] },
    ],
    crops: [
      { key: "paddy",   en: "Paddy",   hi: "धान",    ico: "🌾", msp: 2369, unit: "₹/qtl (Common)" },
      { key: "wheat",   en: "Wheat",   hi: "गेहूँ",   ico: "🌾", msp: 2425, unit: "₹/qtl" },
      { key: "mustard", en: "Mustard", hi: "सरसों",   ico: "🌻", msp: 5950, unit: "₹/qtl" },
      { key: "gram",    en: "Gram",    hi: "चना",    ico: "🫘", msp: 5650, unit: "₹/qtl" },
    ],
    vehicles: [
      { key: "tractor",  en: "Tractor + Trolley", hi: "ट्रैक्टर + ट्रॉली",  ico: "🚜" },
      { key: "pickup",   en: "Pickup Van",        hi: "पिकअप वैन",       ico: "🛻" },
      { key: "mini",     en: "Mini Truck",        hi: "मिनी ट्रक",       ico: "🚚" },
      { key: "bullock",  en: "Bullock Cart",      hi: "बैलगाड़ी",         ico: "🐂" },
    ],
    // Sample booking used by /token and /track pages
    booking: {
      tokenId: "KRN-2026-091043",
      farmer: "रामकिशन सिंह / Ramkishan Singh",
      farmerId: "AGRI-HR-04-88213",
      aadhaarMasked: "XXXX-XXXX-4392",
      village: "Nilokheri, Karnal",
      mandi: "Karnal APMC",
      mandiHi: "करनाल कृषि उपज मंडी",
      crop: "Paddy (Common) / धान",
      quintals: 42,
      msp: 2369,
      vehicle: "Tractor + Trolley — HR-05-AB-4491",
      slotDate: "12 Sept 2026",
      slotWindow: "09:30 — 10:30 AM",
      gate: "Gate 3",
      queuePos: 7,
      etaMin: 34,
    },
  };

  document.addEventListener("DOMContentLoaded", mountChrome);
})();
