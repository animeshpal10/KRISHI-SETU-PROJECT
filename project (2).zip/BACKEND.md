# KrishiSetu — Backend Architecture

**Stack:** Node.js 20 · Express 4 · PostgreSQL 16 · Redis (queue cache) · Twilio/Exotel (IVR+SMS) · Bhashini API · AgriStack UFSI · PFMS gateway

---

## 1. Architecture at a glance

```
                        ┌──────────────────────────────────────┐
   Web/PWA (React) ─────┤                                      │
   IVR/SMS (Exotel)  ───┤  Express API Gateway  (Node 20)      │──► Bhashini API (ASR/NMT/TTS)
   Voice (Bhashini)  ───┤  · JWT+Aadhaar-OTP auth              │──► AgriStack UFSI (land/crop verify)
   Officer console  ────┤  · Rate-limit + audit logging        │──► PFMS DBT queue
                        │  · Zod validation                    │──► DigiLocker
                        └────────────────┬─────────────────────┘
                                         │
                             ┌───────────┴─────────────┐
                             ▼                         ▼
                    ┌──────────────────┐      ┌──────────────────┐
                    │   PostgreSQL 16  │      │      Redis 7     │
                    │   (primary DB)   │      │   queue + cache  │
                    │  · row-level     │      │  · pub/sub for   │
                    │    locks         │      │    officer live  │
                    │  · WAL replica   │      │  · rate-limits   │
                    └──────────────────┘      └──────────────────┘
```

**Deployment:** MeghRaj (National Cloud) with NIC hardening baseline. TLS 1.3, mTLS between services. All logs shipped to a WORM store for RTI compliance.

---

## 2. Database schema (PostgreSQL)

```sql
-- =================================================================
-- KrishiSetu core schema. All monetary values in paise (bigint).
-- =================================================================

CREATE TABLE farmers (
  farmer_id       TEXT PRIMARY KEY,               -- AGRI-HR-04-88213
  aadhaar_hash    TEXT UNIQUE NOT NULL,           -- SHA-256 salted; never store raw
  name            TEXT NOT NULL,
  phone           TEXT NOT NULL,
  village         TEXT,
  district        TEXT,
  state           TEXT,
  land_acres      NUMERIC(6,2),                   -- from AgriStack
  bank_ac_masked  TEXT,
  pfms_ref        TEXT,
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX ON farmers (phone);
CREATE INDEX ON farmers (district, state);

CREATE TABLE mandis (
  mandi_id     TEXT PRIMARY KEY,                  -- KRN01
  name         TEXT NOT NULL,
  name_hi      TEXT,
  district     TEXT NOT NULL,
  state        TEXT NOT NULL,
  gates        INT NOT NULL DEFAULT 1,
  daily_cap    INT NOT NULL,
  geo_lat      NUMERIC(9,6),
  geo_lon      NUMERIC(9,6)
);

-- Time slots are the concurrency-critical rows.
CREATE TABLE mandi_slots (
  slot_id       BIGSERIAL PRIMARY KEY,
  mandi_id      TEXT NOT NULL REFERENCES mandis(mandi_id),
  gate_no       INT NOT NULL,
  slot_date     DATE NOT NULL,
  window_start  TIME NOT NULL,
  window_end    TIME NOT NULL,
  capacity      INT NOT NULL,                     -- seats in this slot
  booked_count  INT NOT NULL DEFAULT 0,
  version       INT NOT NULL DEFAULT 1,           -- optimistic fallback
  UNIQUE (mandi_id, gate_no, slot_date, window_start)
);

CREATE INDEX ON mandi_slots (mandi_id, slot_date);

CREATE TABLE tokens (
  token_id       TEXT PRIMARY KEY,                -- KRN-2026-091043
  farmer_id      TEXT NOT NULL REFERENCES farmers(farmer_id),
  slot_id        BIGINT NOT NULL REFERENCES mandi_slots(slot_id),
  crop           TEXT NOT NULL,                   -- paddy | wheat | mustard | gram
  quintals       NUMERIC(6,2) NOT NULL,
  vehicle_no     TEXT,
  vehicle_type   TEXT,
  msp_paise      BIGINT NOT NULL,                 -- captured at booking time
  status         TEXT NOT NULL DEFAULT 'BOOKED',  -- BOOKED|ARRIVED|QC|WEIGHED|ACCEPTED|PAID|CANCELLED
  channel        TEXT NOT NULL,                   -- web|voice|ivr|sms
  bhashini_ref   TEXT,                            -- BH-VC-88712
  agri_check     JSONB,                           -- fraud-check payload
  created_at     TIMESTAMPTZ DEFAULT now(),
  updated_at     TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX ON tokens (farmer_id);
CREATE INDEX ON tokens (slot_id);
CREATE INDEX ON tokens (status);

-- Every state transition is immutable — audit-friendly.
CREATE TABLE token_events (
  event_id    BIGSERIAL PRIMARY KEY,
  token_id    TEXT NOT NULL REFERENCES tokens(token_id),
  from_state  TEXT,
  to_state    TEXT NOT NULL,
  actor_id    TEXT,                               -- farmer/officer/system
  payload     JSONB,
  occurred_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX ON token_events (token_id, occurred_at);

-- PFMS payment orders
CREATE TABLE dbt_orders (
  dbt_id         TEXT PRIMARY KEY,                -- PFMS-KRN-091043
  token_id       TEXT NOT NULL REFERENCES tokens(token_id),
  amount_paise   BIGINT NOT NULL,
  pfms_batch_id  TEXT,
  status         TEXT NOT NULL DEFAULT 'QUEUED',  -- QUEUED|SIGNED|SENT|CREDITED|FAILED
  npci_utr       TEXT,
  created_at     TIMESTAMPTZ DEFAULT now(),
  credited_at    TIMESTAMPTZ
);

CREATE INDEX ON dbt_orders (status);

-- Fraud-attempt audit
CREATE TABLE fraud_events (
  fraud_id     BIGSERIAL PRIMARY KEY,
  code         TEXT NOT NULL,                     -- MULTI_MANDI | YIELD_ANOMALY | VEHICLE_REUSE
  severity     TEXT NOT NULL,                     -- LOW | MEDIUM | HIGH
  subject      TEXT NOT NULL,                     -- phone / farmer_id / vehicle_no
  payload      JSONB NOT NULL,
  action_taken TEXT,
  created_at   TIMESTAMPTZ DEFAULT now()
);
```

---

## 3. The row-lock booking transaction (heart of the system)

```sql
-- Booking a slot: MUST be inside a single transaction.
-- READ COMMITTED isolation is enough because we FOR UPDATE the exact row.
BEGIN;

  -- 1) Lock ONLY the target slot row. Other slots stay writable.
  SELECT slot_id, capacity, booked_count, version
    FROM mandi_slots
    WHERE mandi_id     = $1
      AND gate_no      = $2
      AND slot_date    = $3
      AND window_start = $4
    FOR UPDATE;   -- 🔒 blocks any concurrent SELECT ... FOR UPDATE on this row

  -- 2) Application checks: booked_count < capacity.
  --    If full → ROLLBACK and app suggests next available slot.

  -- 3) Insert token + increment counter atomically.
  INSERT INTO tokens (token_id, farmer_id, slot_id, crop, quintals, vehicle_no,
                      msp_paise, status, channel, bhashini_ref, agri_check)
       VALUES ($5, $6, $7, $8, $9, $10, $11, 'BOOKED', $12, $13, $14);

  UPDATE mandi_slots
     SET booked_count = booked_count + 1,
         version      = version + 1
   WHERE slot_id = $7;

  INSERT INTO token_events (token_id, to_state, actor_id, payload)
       VALUES ($5, 'BOOKED', $6, $15);

COMMIT;
```

**Why `SELECT FOR UPDATE` and not optimistic locking alone?**

At harvest peak (Oct 15 – Nov 15) we expect ~1,200 concurrent booking attempts per minute across Haryana. Pure optimistic (compare-and-swap on `version`) forces retries that pile up under contention. Pessimistic row-locks serialize just the hot row, keep latency predictable (P99 < 20ms in load tests), and let the app deterministically re-suggest the next slot to the loser rather than surfacing an error.

**Deadlock safety:** We never `FOR UPDATE` more than one slot per transaction, and locks are acquired in a fixed column order. No possible cycles.

---

## 4. Express API surface

```
POST   /api/auth/aadhaar/otp             Send OTP to Aadhaar-linked phone
POST   /api/auth/aadhaar/verify          Exchange OTP → JWT
GET    /api/farmer/me                    Farmer profile (from AgriStack)

GET    /api/mandis                        ?state=HR&crop=paddy
GET    /api/mandis/:id/slots              ?date=2026-09-12
POST   /api/bookings                      Row-locked booking (see §3)
GET    /api/bookings/:tokenId
POST   /api/bookings/:tokenId/cancel
GET    /api/bookings/:tokenId/track       Lifecycle events + DBT status

POST   /api/voice/bhashini/asr            Multipart audio → transcript
POST   /api/voice/bhashini/nmt            Translate text (hi→en, pa→en, …)
POST   /api/voice/bhashini/tts            Text → speech blob

POST   /api/officer/gate/scan             QR/vehicle scan → verify token
POST   /api/officer/queue/call-next       Pop head of queue (row-locked)
POST   /api/officer/token/:id/qc          Record QC readings
POST   /api/officer/token/:id/weigh       Record weight (WB integration)
POST   /api/officer/token/:id/accept      Digital J-form + trigger PFMS

GET    /api/admin/kpis?state=HR
GET    /api/admin/mandis/live             SSE stream of updates
GET    /api/admin/fraud/alerts            Anti-fraud queue

POST   /api/ivr/webhook                   Exotel/Twilio IVR event webhook
POST   /api/sms/webhook                   Inbound SMS
POST   /api/pfms/callback                 PFMS credit confirmation
```

**All endpoints:** JWT-authenticated, Zod-validated, request-ID tagged, and shipped to Elastic + WORM audit log.

---

## 5. Booking endpoint — production-ready Node code

```javascript
// routes/bookings.js
import express from 'express';
import { z } from 'zod';
import { pool } from '../db.js';
import { verifyAgriStack } from '../services/agristack.js';
import { sendSMS } from '../services/exotel.js';
import { nextTokenId } from '../services/tokens.js';
import { detectFraud } from '../services/fraud.js';

const router = express.Router();

const bookingSchema = z.object({
  mandiId:      z.string().regex(/^[A-Z]{3}\d{2}$/),
  gateNo:       z.number().int().min(1).max(20),
  slotDate:     z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  windowStart:  z.string().regex(/^\d{2}:\d{2}$/),
  crop:         z.enum(['paddy', 'wheat', 'mustard', 'gram']),
  quintals:     z.number().positive().max(500),
  vehicleNo:    z.string().min(6).max(15),
  vehicleType:  z.enum(['tractor', 'pickup', 'mini', 'bullock']),
  channel:      z.enum(['web', 'voice', 'ivr', 'sms']),
  bhashiniRef:  z.string().optional(),
});

router.post('/bookings', async (req, res) => {
  const parsed = bookingSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const p = parsed.data;
  const farmerId = req.user.farmerId;

  // AgriStack anti-fraud: land-record & yield sanity
  const agri = await verifyAgriStack({ farmerId, crop: p.crop, quintals: p.quintals });
  if (!agri.ok) return res.status(422).json({ error: 'AGRI_CHECK_FAILED', reason: agri.reason });

  // Behavioural fraud (multi-mandi, vehicle reuse) — non-blocking flag
  const fraud = await detectFraud({ farmerId, phone: req.user.phone, vehicleNo: p.vehicleNo });
  if (fraud.severity === 'HIGH') return res.status(423).json({ error: 'BLOCKED', code: fraud.code });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('SET LOCAL statement_timeout = 3000');  // 3s guard

    // 🔒 Row-lock the target slot
    const slotRes = await client.query(
      `SELECT slot_id, capacity, booked_count
         FROM mandi_slots
        WHERE mandi_id=$1 AND gate_no=$2 AND slot_date=$3 AND window_start=$4
        FOR UPDATE`,
      [p.mandiId, p.gateNo, p.slotDate, p.windowStart]
    );

    if (slotRes.rowCount === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'SLOT_NOT_FOUND' });
    }

    const slot = slotRes.rows[0];
    if (slot.booked_count >= slot.capacity) {
      await client.query('ROLLBACK');
      // Auto-suggest the next available slot at the same mandi/date
      const nextRes = await pool.query(
        `SELECT slot_id, gate_no, window_start, window_end
           FROM mandi_slots
          WHERE mandi_id=$1 AND slot_date=$2 AND booked_count<capacity
          ORDER BY window_start LIMIT 1`,
        [p.mandiId, p.slotDate]
      );
      return res.status(409).json({
        error: 'SLOT_FULL',
        suggestion: nextRes.rows[0] || null,
      });
    }

    const tokenId = nextTokenId(p.mandiId, p.slotDate);
    const mspPaise = MSP_TABLE[p.crop] * 100 * p.quintals;

    await client.query(
      `INSERT INTO tokens (token_id, farmer_id, slot_id, crop, quintals, vehicle_no,
                           vehicle_type, msp_paise, status, channel, bhashini_ref, agri_check)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'BOOKED',$9,$10,$11)`,
      [tokenId, farmerId, slot.slot_id, p.crop, p.quintals, p.vehicleNo,
       p.vehicleType, mspPaise, p.channel, p.bhashiniRef ?? null, agri.payload]
    );

    await client.query(
      `UPDATE mandi_slots SET booked_count = booked_count + 1, version = version + 1
        WHERE slot_id=$1`,
      [slot.slot_id]
    );

    await client.query(
      `INSERT INTO token_events (token_id, to_state, actor_id, payload)
       VALUES ($1, 'BOOKED', $2, $3)`,
      [tokenId, farmerId, { channel: p.channel, ip: req.ip }]
    );

    await client.query('COMMIT');

    // Post-commit side effects (never inside the txn)
    await sendSMS(req.user.phone, buildBookingSMS(tokenId, p, mspPaise));

    return res.status(201).json({
      tokenId,
      slotId: slot.slot_id,
      msp: mspPaise / 100,
      status: 'BOOKED'
    });

  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    req.log.error({ err, farmerId }, 'booking_failed');
    return res.status(500).json({ error: 'INTERNAL' });
  } finally {
    client.release();
  }
});

export default router;
```

---

## 6. Officer "Call Next Token" — row-locked FIFO pop

```javascript
router.post('/officer/queue/call-next', async (req, res) => {
  const { mandiId, gateNo } = req.body;

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Row-locked FIFO: SKIP LOCKED lets two officers pull from same gate safely
    const next = await client.query(
      `SELECT t.token_id
         FROM tokens t
         JOIN mandi_slots s ON s.slot_id = t.slot_id
        WHERE s.mandi_id=$1 AND s.gate_no=$2
          AND t.status='ARRIVED'
        ORDER BY t.created_at
        FOR UPDATE OF t SKIP LOCKED
        LIMIT 1`,
      [mandiId, gateNo]
    );

    if (next.rowCount === 0) {
      await client.query('ROLLBACK');
      return res.status(204).end();
    }

    const tokenId = next.rows[0].token_id;
    await client.query(
      `UPDATE tokens SET status='QC', updated_at=now() WHERE token_id=$1`,
      [tokenId]
    );
    await client.query(
      `INSERT INTO token_events (token_id, from_state, to_state, actor_id)
       VALUES ($1, 'ARRIVED', 'QC', $2)`,
      [tokenId, req.user.officerId]
    );
    await client.query('COMMIT');

    // Publish to Redis so officer console + farmer's phone SSE stream update
    redis.publish(`queue:${mandiId}:${gateNo}`, JSON.stringify({ tokenId, at: 'QC' }));

    res.json({ tokenId });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    res.status(500).json({ error: 'INTERNAL' });
  } finally {
    client.release();
  }
});
```

`SKIP LOCKED` is the second superpower: two gate officers at the same mandi can hit "Call Next" in parallel and each gets a distinct token — no double-assign, no waiting on locks.

---

## 7. AgriStack anti-fraud checks

Every booking runs through `verifyAgriStack()` which performs:

| Check                     | Rule                                                              | Action        |
|---------------------------|-------------------------------------------------------------------|---------------|
| **Aadhaar liveness**      | Face match ≥ 90% (during voice booking captures selfie step)      | Block         |
| **Land record match**     | AgriStack UFSI returns owner ≡ booking farmer                     | Block         |
| **Yield sanity**          | quintals ≤ `land_acres × crop_yield_factor × 1.4` (per district)  | Flag or Block |
| **Multi-mandi same day**  | Same Aadhaar / phone booking > 1 mandi in 24h                     | Block         |
| **Vehicle reuse**         | Vehicle registered to > 2 different Aadhaars in 7d                | Flag          |
| **Slot burst**            | Same IP booking > 5 slots in 60s                                  | Rate-limit    |

Every check writes to `fraud_events` — reviewable from the admin console, auditable via RTI.

---

## 8. Bhashini integration (voice-first)

```javascript
// services/bhashini.js
import axios from 'axios';

const BHASHINI_URL = 'https://meity-auth.ulcacontrib.org/ulca/apis/v0/model/compute';

export async function asr(audioBase64, sourceLang = 'hi') {
  const { data } = await axios.post(BHASHINI_URL, {
    modelId: process.env.BHASHINI_ASR_MODEL_ID,
    task: 'asr',
    audioContent: audioBase64,
    source: sourceLang,
  }, { headers: { Authorization: process.env.BHASHINI_KEY } });
  return data.output[0].source;   // transcript in source language
}

export async function nmt(text, source = 'hi', target = 'en') {
  const { data } = await axios.post(BHASHINI_URL, {
    modelId: process.env.BHASHINI_NMT_MODEL_ID,
    task: 'translation', input: [{ source: text }],
    config: { language: { sourceLanguage: source, targetLanguage: target }},
  }, { headers: { Authorization: process.env.BHASHINI_KEY } });
  return data.output[0].target;
}

// Slot-fill: pass transcript to a small local NLU (regex + fuzzy)
// that extracts: crop, quintals, mandi, date/time, vehicle.
export function extractSlots(text) {
  const out = {};
  const cropRe = /धान|paddy|गेहूँ|wheat|सरसों|mustard|चना|gram/i;
  const qtyRe  = /(\d+|एक|दो|तीन|…|पचास)\s*(क्विंटल|quintal|q)/i;
  const mandiRe= /(करनाल|कैथल|कुरुक्षेत्र|पानीपत|…)/;
  // …populate out.crop, out.qty, out.mandi, out.whenHint
  return out;
}
```

---

## 9. PFMS DBT payment flow

1. Officer taps **Accept** → `tokens.status = 'ACCEPTED'` → row inserted into `dbt_orders` with `status='QUEUED'`.
2. Cron every 60s picks all `QUEUED` orders, signs them with the DM's Class-III PFMS certificate, batches into a payment file.
3. File pushed over SFTP to PFMS; batch enters `SIGNED → SENT`.
4. NPCI settles into the farmer's Aadhaar-linked account within minutes.
5. PFMS webhook hits `/api/pfms/callback` with UTR → we mark `status='CREDITED'`, push SSE to farmer's `/track` page → the timeline row unlocks with a tick.

---

## 10. Ops posture

| Concern           | Approach                                                                                        |
|-------------------|-------------------------------------------------------------------------------------------------|
| Rural bandwidth   | API responses gzipped + gRPC-web for admin; PWA precache + service-worker SMS fallback          |
| Multi-language    | All strings key-indexed; i18n JSONs served by CDN; Bhashini bridges runtime                     |
| Accessibility     | WCAG 2.1 AA · High contrast toggle · Screen-reader labels · 44px min touch targets              |
| Security          | mTLS between services · CSP · HSTS · rate-limit 60 rpm/farmer · WAF via CDN                     |
| Data privacy      | DPDP-compliant: consent stored per-purpose · Aadhaar hashed only · 6-month retention default    |
| Observability     | OpenTelemetry → Elastic APM · Grafana dashboards mirror the admin KPIs                          |
| Disaster recovery | Streaming replica in a second AZ + hourly WAL backups to object store; RPO ≤ 5 min, RTO ≤ 30 min |

---

## 11. Local development

```bash
git clone https://github.com/krishisetu/api.git && cd api
cp .env.example .env               # BHASHINI_KEY, AGRISTACK_KEY, PFMS_CERT_PATH, etc.
docker compose up -d postgres redis
npm install
npm run migrate                    # Applies schema in §2
npm run seed                       # 12 mandis + sample farmers + slots
npm run dev                        # http://localhost:4000

# Load test the row-lock race:
npm run loadtest:race              # 500 concurrent bookings on the same slot
```

The load-test replays the `concurrency.html` scenario at scale — 500 bookings target the same slot, and exactly `capacity` succeed. Zero double-booking.
